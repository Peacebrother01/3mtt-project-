<?php
include '../includes/db.php';
session_start();

$id = $_GET['id'];
$sql = "DELETE FROM departments WHERE id = $id";
mysqli_query($conn, $sql);
header("Location: manage_department.php");
