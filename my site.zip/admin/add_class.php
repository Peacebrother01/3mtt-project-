<?php
include '../includes/db.php';
session_start();

// Fetch departments
$departments = mysqli_query($conn, "SELECT * FROM departments");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $class_name = $_POST['class_name'];
    $department_id = $_POST['department_id'];

    $stmt = $conn->prepare("INSERT INTO classes (class_name, department_id) VALUES (?, ?)");
    $stmt->bind_param("si", $class_name, $department_id);
    $stmt->execute();

    header("Location: manage_class.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Class</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<?php include 'admin_header_info.php'; ?>
    <?php include 'admin_sidebar.php'; ?>

    <div class="container mt-5">
        <h2 class="mb-4">Add New Class</h2>
        <form method="post">
            <div class="form-group">
                <label>Class Name</label>
                <input type="text" name="class_name" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Department</label>
                <select name="department_id" class="form-control" required>
                    <option value="">-- Select Department --</option>
                    <?php while ($dept = mysqli_fetch_assoc($departments)) {
                        echo "<option value='{$dept['id']}'>{$dept['name']}</option>";
                    } ?>
                </select>
            </div>
            <button type="submit" class="btn btn-success">Add Class</button>
            <a href="manage_class.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <?php include 'admin_footer.php'; ?>
