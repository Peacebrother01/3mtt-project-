<?php
// admin/edit_lecturer.php
include '../includes/db.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id'])) {
    $_SESSION['error'] = "Invalid request.";
    header("Location: manage_lecturer.php");
    exit();
}

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM users WHERE id = '$id' AND role = 'instructor'");
$user = mysqli_fetch_assoc($result);

if (!$user) {
    $_SESSION['error'] = "Lecturer not found.";
    header("Location: manage_lecturer.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (!empty($password)) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $sql = "UPDATE users SET full_name='$fullname', email='$email', password='$hashed' WHERE id='$id'";
    } else {
        $sql = "UPDATE users SET full_name='$fullname', email='$email' WHERE id='$id'";
    }

    if (mysqli_query($conn, $sql)) {
        $_SESSION['success'] = "Lecturer updated successfully.";
        header("Location: manage_lecturer.php");
    } else {
        $_SESSION['error'] = "Update failed.";
        header("Location: edit_lecturer.php?id=$id");
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Lecturer</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<?php include 'admin_header_info.php'; ?>
<?php include 'admin_sidebar.php'; ?>
<div class="container mt-5">
    <h2>Edit Lecturer</h2>
    <form method="POST">
        <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="full_name" class="form-control" value="<?= $user['full_name']; ?>" required>
        </div>
        <div class="form-group">
            <label>Email Address</label>
            <input type="email" name="email" class="form-control" value="<?= $user['email']; ?>" required>
        </div>
        <div class="form-group">
            <label>New Password <small>(Leave blank to keep current password)</small></label>
            <input type="password" name="password" class="form-control">
        </div>
        <button class="btn btn-primary" type="submit">Update</button>
        <a href="manage_lecturer.php" class="btn btn-secondary">Back</a>
    </form>
</div>
<?php include 'admin_footer.php'; ?>
</body>
</html>
