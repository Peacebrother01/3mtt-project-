<!-- sidebar.php -->
<div class="d-flex">
  <div class="bg-light border" style="width: 250px; min-height: 100vh;">
    <ul class="nav flex-column p-3">
      <li class="nav-item">
        <a class="nav-link active" href="admin_dashboard.php"><i class="fa fa-home"></i> Dashboard</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="manage_admin.php"><i class="fa fa-users"></i> Manage Admin Users</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="manage_class.php"><i class="fa fa-chalkboard"></i> Manage Classes</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="manage_subject.php"><i class="fa fa-chalkboard"></i> Manage Subject</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="manage_lectures.php"><i class="fa fa-chalkboard"></i> Manage Lectures</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="manage_department.php"><i class="fa fa-chalkboard"></i> Manage Department</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="manage_student.php"><i class="fa fa-chalkboard"></i> Manage Student</a>
      </li><li class="nav-item">
        <a class="nav-link" href="Manage_lecturer.php"><i class="fa fa-chalkboard"></i> Manage Lecturer</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="user_log.php"><i class="fa fa-chalkboard"></i> User Log</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"><i class="fa fa-cog"></i> Activity Log</a>
      </li>
    </ul>
  </div>
