<?php
include '../includes/db.php';
session_start();

$id = $_GET['id'];
$success = "";
$error = "";

// Fetch current admin data
$sql = "SELECT * FROM users WHERE id = $id AND role='admin'";
$result = mysqli_query($conn, $sql);
$admin = mysqli_fetch_assoc($result);

if (!$admin) {
    die("Admin not found.");
}

// Update on form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    // Optional password update
    if (!empty($_POST['password'])) {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $sql = "UPDATE users SET full_name='$fullname', email='$email', password='$password' WHERE id=$id";
    } else {
        $sql = "UPDATE users SET full_name='$fullname', email='$email' WHERE id=$id";
    }

    if (mysqli_query($conn, $sql)) {
        $success = "Admin updated successfully.";
        // Refresh the admin data
        $result = mysqli_query($conn, "SELECT * FROM users WHERE id = $id");
        $admin = mysqli_fetch_assoc($result);
    } else {
        $error = "Error updating admin: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Admin User</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<?php include 'admin_header_info.php'; ?>
<?php include 'admin_sidebar.php'; ?>
<div class="container mt-5">
    <h2 class="mb-4">Edit Admin User</h2>

    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php elseif ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label for="full_name">Full Name</label>
            <input type="text" name="full_name" value="<?php echo $admin['full_name']; ?>" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" name="email" value="<?php echo $admin['email']; ?>" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="password">New Password (leave blank to keep current)</label>
            <input type="password" name="password" class="form-control">
        </div>

        <button type="submit" class="btn btn-warning">Update Admin</button>
        <a href="manage_admin.php" class="btn btn-secondary">Back</a>
    </form>
</div>
<?php include 'admin_footer.php'; ?>