<?php
// admin/add_lecturer.php
include '../includes/db.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $fullname = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = 'instructor';

    // Check for duplicate email
    $check = mysqli_query($conn, "SELECT * FROM users WHERE email = '$email'");
    if (mysqli_num_rows($check) > 0) {
        $_SESSION['error'] = "Email already exists!";
        header("Location: add_lecturer.php");
        exit();
    }

    $sql = "INSERT INTO users (full_name, email, password, role) VALUES ('$fullname', '$email', '$password', '$role')";
    if (mysqli_query($conn, $sql)) {
        $_SESSION['success'] = "Lecturer added successfully.";
        header("Location: manage_lecturer.php");
    } else {
        $_SESSION['error'] = "Error adding lecturer.";
        header("Location: add_lecturer.php");
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Lecturer</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<?php include 'admin_header_info.php'; ?>
<?php include 'admin_sidebar.php'; ?>
<div class="container mt-5">
    <h2>Add New Lecturer</h2>
    <form method="POST" action="">
        <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="full_name" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Email Address</label>
            <input type="email" name="email" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Password (default)</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <button class="btn btn-success" type="submit">Add Lecturer</button>
        <a href="manage_lecturer.php" class="btn btn-secondary">Back</a>
    </form>
</div>
<?php include 'admin_footer.php'; ?>
</body>
</html>
