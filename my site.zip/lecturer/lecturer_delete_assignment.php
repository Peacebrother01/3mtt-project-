<?php
// lecturer_delete_assignment.php
session_start();
require_once "../includes/db.php";

// Redirect if not a lecturer
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

$lecturer_id = $_SESSION['user']['id'];

// Validate assignment ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: lecturer_manage_assignments.php");
    exit();
}
$assignment_id = (int)$_GET['id'];

// Fetch the assignment to verify ownership
$stmt = $conn->prepare("SELECT * FROM assignments WHERE id = ? AND lecturer_id = ?");
$stmt->bind_param("ii", $assignment_id, $lecturer_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    $_SESSION['message'] = "Assignment not found or access denied.";
    header("Location: lecturer_manage_assignments.php");
    exit();
}
$assignment = $result->fetch_assoc();

// Handle assignment deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Remove file from the server if it exists
    if ($assignment['file_path'] && file_exists($assignment['file_path'])) {
        unlink($assignment['file_path']);
    }

    // Delete assignment from the database
    $deleteStmt = $conn->prepare("DELETE FROM assignments WHERE id = ? AND lecturer_id = ?");
    $deleteStmt->bind_param("ii", $assignment_id, $lecturer_id);

    if ($deleteStmt->execute()) {
        $_SESSION['message'] = "Assignment deleted successfully.";
        header("Location: lecturer_manage_assignments.php");
        exit();
    } else {
        $_SESSION['message'] = "Error deleting assignment.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Delete Assignment</title>
  

<?php include 'lecturer_header_info.php'; ?>

<body>
<div class="container-fluid">
  <div class="row">
    <?php include 'lecturer_sidebar.php'; ?>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
      <h2 class="mb-4">Delete Assignment</h2>

      <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-info">
          <?= $_SESSION['message']; unset($_SESSION['message']); ?>
        </div>
      <?php endif; ?>

      <div class="card p-4 shadow-sm">
        <h5>Are you sure you want to delete the assignment titled: <strong><?= htmlspecialchars($assignment['title']) ?></strong>?</h5>
        <form method="post" class="mt-3">
          <button type="submit" class="btn btn-danger">Yes, Delete</button>
          <a href="lecturer_manage_assignments.php" class="btn btn-secondary ms-2">Cancel</a>
        </form>
      </div>
    </main>
  </div>
</div>
</body>
</html>
