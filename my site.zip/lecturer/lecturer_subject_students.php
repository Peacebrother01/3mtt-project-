<?php
session_start();
require_once "../includes/db.php";

// Ensure the user is an instructor
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

$lecturer_id = $_SESSION['user']['id'];

// Check for subject ID
if (!isset($_GET['subject_id'])) {
    $_SESSION['message'] = "No subject selected.";
    header("Location: lecturer_my_subjects.php");
    exit();
}

$subject_id = intval($_GET['subject_id']);

// Verify lecturer owns this subject
$verify_sql = "SELECT * FROM lecturer_subjects WHERE lecturer_id = $lecturer_id AND subject_id = $subject_id";
$verify_result = mysqli_query($conn, $verify_sql);

if (mysqli_num_rows($verify_result) == 0) {
    $_SESSION['message'] = "Unauthorized access.";
    header("Location: lecturer_my_subjects.php");
    exit();
}

// Fetch subject name
$subject_name = '';
$sub_res = mysqli_query($conn, "SELECT name FROM subjects WHERE id = $subject_id");
if ($row = mysqli_fetch_assoc($sub_res)) {
    $subject_name = $row['name'];
}

// Fetch students assigned to this subject
$sql_students = "SELECT u.id, u.full_name, u.email 
                 FROM student_subjects ss
                 JOIN users u ON ss.student_id = u.id
                 WHERE ss.subject_id = $subject_id";

$result_students = mysqli_query($conn, $sql_students);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Students for <?= htmlspecialchars($subject_name) ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<?php include 'lecturer_header_info.php'; ?>

<div class="container mt-5">
    <h3>Students Assigned to Subject: <strong><?= htmlspecialchars($subject_name) ?></strong></h3>
    <a href="lecturer_my_subjects.php" class="btn btn-secondary mb-3">← Back to My Subjects</a>

    <?php if (mysqli_num_rows($result_students) > 0): ?>
        <table class="table table-bordered">
            <thead class="thead-light">
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($student = mysqli_fetch_assoc($result_students)): ?>
                    <tr>
                        <td><?= htmlspecialchars($student['full_name']) ?></td>
                        <td><?= htmlspecialchars($student['email']) ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No students have been assigned to this subject yet.</p>
    <?php endif; ?>
</div>

</body>
</html>
