<!-- footer.php -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<footer class="bg-dark text-white mt-5 p-0 text-center fixed-bottom">
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> Collaborative E-Learning System. All rights reserved.</p>
        <p>Designed and developed by Adedayo</p>
    </div>
</footer>
</body>
</html>
