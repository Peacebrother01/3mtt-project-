<?php
session_start();
require_once "../includes/db.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sender_id = $_SESSION['user']['id'];
    $receiver_id = $_POST['receiver_id'];
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    $sql = "INSERT INTO messages (sender_id, receiver_id, subject, message)
            VALUES ($sender_id, $receiver_id, '$subject', '$message')";

    if ($conn->query($sql)) {
        $_SESSION['message'] = "Message sent successfully.";
    } else {
        $_SESSION['message'] = "Error sending message.";
    }

    header("Location: lecturer_send_message.php");
    exit();
} else {
    header("Location: lecturer_send_message.php");
    exit();
}
