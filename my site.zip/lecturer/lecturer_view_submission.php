<?php
// lecturer_view_submissions.php
session_start();
require_once "../includes/db.php";

// Redirect if not a lecturer
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

$lecturer_id = $_SESSION['user']['id'];

if (!isset($_GET['assignment_id']) || !is_numeric($_GET['assignment_id'])) {
    header("Location: lecturer_manage_assignments.php");
    exit();
}
$assignment_id = (int)$_GET['assignment_id'];

// Verify this assignment belongs to this lecturer
$stmt = $conn->prepare("
    SELECT id, title 
    FROM assignments 
    WHERE id = ? AND lecturer_id = ?
");
$stmt->bind_param("ii", $assignment_id, $lecturer_id);
$stmt->execute();
$asg = $stmt->get_result()->fetch_assoc();
if (!$asg) {
    $_SESSION['message'] = "Assignment not found or access denied.";
    header("Location: lecturer_manage_assignments.php");
    exit();
}

// Handle grading submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submission_id'])) {
    $submission_id = (int)$_POST['submission_id'];
    $grade         = $conn->real_escape_string($_POST['grade']);
    $feedback      = $conn->real_escape_string($_POST['feedback']);

    $upd = $conn->prepare("
        UPDATE assignment_submissions
        SET grade = ?, feedback = ?
        WHERE id = ?
    ");
    $upd->bind_param("ssi", $grade, $feedback, $submission_id);
    $upd->execute();
    $_SESSION['message'] = "Grade updated.";
    header("Location: lecturer_view_submission.php?assignment_id=$assignment_id");
    exit();
}

// Fetch all submissions for this assignment
$subsQ = $conn->prepare("
    SELECT sub.id, sub.student_id, sub.file_path, sub.submission_date, sub.grade, sub.feedback,
           u.full_name AS student_name
    FROM assignment_submissions sub
    JOIN users u ON sub.student_id = u.id
    WHERE sub.assignment_id = ?
    ORDER BY sub.submission_date DESC
");
$subsQ->bind_param("i", $assignment_id);
$subsQ->execute();
$submissions = $subsQ->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Submissions for “<?= htmlspecialchars($asg['title']) ?>”</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'lecturer_sidebar.php'; ?>

<div class="container mt-4">
  <h2>Submissions: <?= htmlspecialchars($asg['title']) ?></h2>

  <?php if (isset($_SESSION['message'])): ?>
    <div class="alert alert-info"><?= $_SESSION['message']; unset($_SESSION['message']); ?></div>
  <?php endif; ?>

  <?php if ($submissions->num_rows === 0): ?>
    <div class="alert alert-warning">No submissions yet.</div>
  <?php else: ?>
    <table class="table table-bordered">
      <thead class="table-dark">
        <tr>
          <th>Student</th>
          <th>File</th>
          <th>Submitted At</th>
          <th>Grade</th>
          <th>Feedback</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php while ($row = $submissions->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($row['student_name']) ?></td>
          <td>
            <?php if ($row['file_path']): ?>
              <a href="<?= htmlspecialchars($row['file_path']) ?>" target="_blank">Download</a>
            <?php else: ?>—
            <?php endif; ?>
          </td>
          <td><?= date("d M Y H:i", strtotime($row['submission_date'])) ?></td>
          <td><?= htmlspecialchars($row['grade'] ?? '') ?></td>
          <td><?= nl2br(htmlspecialchars($row['feedback'] ?? '')) ?></td>
          <td>
            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#gradeModal<?= $row['id'] ?>">
              Grade
            </button>
            <!-- Grade Modal -->
            <div class="modal fade" id="gradeModal<?= $row['id'] ?>" tabindex="-1">
              <div class="modal-dialog">
                <form method="post" class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title">Grade <?= htmlspecialchars($row['student_name']) ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                  </div>
                  <div class="modal-body">
                    <input type="hidden" name="submission_id" value="<?= $row['id'] ?>">
                    <div class="mb-3">
                      <label class="form-label">Grade</label>
                      <input type="text" name="grade" class="form-control" value="<?= htmlspecialchars($row['grade']) ?>">
                    </div>
                    <div class="mb-3">
                      <label class="form-label">Feedback</label>
                      <textarea name="feedback" class="form-control"><?= htmlspecialchars($row['feedback']) ?></textarea>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                  </div>
                </form>
              </div>
            </div>
          </td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
