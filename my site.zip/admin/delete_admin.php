<?php
include '../includes/db.php';
session_start();

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Prevent deleting yourself
    if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $id) {
        $_SESSION['error'] = "You cannot delete your own account.";
        header("Location: manage_admin.php");
        exit();
    }

    // Delete admin from DB
    $sql = "DELETE FROM users WHERE id=$id AND role='admin'";
    if (mysqli_query($conn, $sql)) {
        $_SESSION['success'] = "Admin user deleted successfully.";
    } else {
        $_SESSION['error'] = "Error deleting admin user: " . mysqli_error($conn);
    }
}

header("Location: manage_admin.php");
exit();
