<?php
include '../includes/db.php';
session_start();

// Fetch departments for the dropdown
$sql_departments = "SELECT * FROM departments";
$departments_result = mysqli_query($conn, $sql_departments);

// Fetch lecturers (users with role 'instructor')
$sql_lecturers = "SELECT * FROM users WHERE role='instructor'";
$lecturers_result = mysqli_query($conn, $sql_lecturers);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form input values
    $subject_name = mysqli_real_escape_string($conn, $_POST['subject_name']);
    $department_id = $_POST['department_id'];
    $lecturer_id = $_POST['lecturer_id'];

    // Insert new subject into the database
    $sql_insert = "INSERT INTO subjects (name, department_id, lecturer_id) 
                   VALUES ('$subject_name', '$department_id', '$lecturer_id')";
    
    if (mysqli_query($conn, $sql_insert)) {
        // Get the newly inserted subject ID
        $subject_id = mysqli_insert_id($conn);

        // Prevent duplicate entries in lecturer_subjects
        $check_duplicate = "SELECT * FROM lecturer_subjects WHERE lecturer_id = '$lecturer_id' AND subject_id = '$subject_id'";
        $result = mysqli_query($conn, $check_duplicate);

        if (mysqli_num_rows($result) == 0) {
            // Insert into lecturer_subjects table if not a duplicate
            $sql_link = "INSERT INTO lecturer_subjects (lecturer_id, subject_id) 
                         VALUES ('$lecturer_id', '$subject_id')";
            mysqli_query($conn, $sql_link);
        }

        $_SESSION['message'] = 'Subject added successfully';
        header('Location: manage_subject.php');
        exit;
    } else {
        $_SESSION['message'] = 'Error adding subject';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Subject</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>

<?php include 'admin_header_info.php'; ?>
<?php include 'admin_sidebar.php'; ?>

<div class="container mt-5">
    <h2 class="mb-4">Add New Subject</h2>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-info"><?= $_SESSION['message'] ?></div>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <form action="add_subject.php" method="POST">
        <div class="form-group">
            <label for="subject_name">Subject Name</label>
            <input type="text" class="form-control" id="subject_name" name="subject_name" required>
        </div>

        <div class="form-group">
            <label for="department_id">Department</label>
            <select class="form-control" id="department_id" name="department_id" required>
                <option value="">Select Department</option>
                <?php while ($row = mysqli_fetch_assoc($departments_result)): ?>
                    <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['name']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="lecturer_id">Lecturer</label>
            <select class="form-control" id="lecturer_id" name="lecturer_id" required>
                <option value="">Select Lecturer</option>
                <?php while ($row = mysqli_fetch_assoc($lecturers_result)): ?>
                    <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['full_name']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Add Subject</button>
    </form>
</div>

<?php include 'admin_footer.php'; ?>

</html>
