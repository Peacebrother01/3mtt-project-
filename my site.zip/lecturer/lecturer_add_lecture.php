<?php
session_start();
require_once "../includes/db.php";

// Redirect if not a lecturer
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

$lecturer_id = $_SESSION['user']['id'];

// Fetch subjects assigned to this lecturer
$subjectResult = $conn->query("SELECT subjects.id, subjects.name 
    FROM subjects 
    JOIN lecturer_subjects ON subjects.id = lecturer_subjects.subject_id 
    WHERE lecturer_subjects.lecturer_id = $lecturer_id");

$subjects = [];
while ($row = $subjectResult->fetch_assoc()) {
    $subjects[] = $row;
}

// Fetch all classes
$classResult = $conn->query("SELECT * FROM classes");
$classes = [];
while ($row = $classResult->fetch_assoc()) {
    $classes[] = $row;
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $subject_id = $_POST['subject_id'];
    $class_id = $_POST['class_id'];
    $uploaded_by = $_SESSION['user']['id'];

    // Handle file upload
    if (isset($_FILES['lecture_file']) && $_FILES['lecture_file']['error'] === 0) {
        $file_name = $_FILES['lecture_file']['name'];
        $file_tmp = $_FILES['lecture_file']['tmp_name'];
        $file_type = $_FILES['lecture_file']['type'];
        $destination = "../uploads/" . $file_name;

        if (move_uploaded_file($file_tmp, $destination)) {
            $stmt = $conn->prepare("INSERT INTO lectures (title, description, subject_id, class_id, file_path, file_type, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssisssi", $title, $description, $subject_id, $class_id, $destination, $file_type, $uploaded_by);

            if ($stmt->execute()) {
                $message = "<div class='alert alert-success'>Lecture uploaded successfully.</div>";
            } else {
                $message = "<div class='alert alert-danger'>Error saving lecture to database.</div>";
            }
        } else {
            $message = "<div class='alert alert-danger'>Failed to upload file.</div>";
        }
    } else {
        $message = "<div class='alert alert-warning'>Please select a valid file.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Lecture</title>
    

<?php include 'lecturer_header_info.php'; ?>
<?php include 'lecturer_sidebar.php'; ?>

<body>
<div class="container mt-5">
    <h2>Add New Lecture</h2>
    <?= $message ?>

    <form action="" method="POST" enctype="multipart/form-data" class="mt-4">
        <div class="mb-3">
            <label for="title" class="form-label">Lecture Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Lecture Description</label>
            <textarea name="description" class="form-control" required></textarea>
        </div>

        <div class="mb-3">
            <label for="subject_id" class="form-label">Subject</label>
            <select name="subject_id" class="form-control" required>
                <option value="">-- Select Subject --</option>
                <?php foreach ($subjects as $subject): ?>
                    <option value="<?= $subject['id']; ?>"><?= $subject['name']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="class_id" class="form-label">Class</label>
            <select name="class_id" class="form-control" required>
                <option value="">-- Select Class --</option>
                <?php foreach ($classes as $class): ?>
                    <option value="<?= $class['id']; ?>"><?= $class['class_name']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="lecture_file" class="form-label">Upload File</label>
            <input type="file" name="lecture_file" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Upload Lecture</button>
    </form>
    <br/><br/><br/><br/><br/>
</div>
<?php include "lecturer_footer.php"; ?>
