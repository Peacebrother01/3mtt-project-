<?php
include '../includes/db.php';
session_start();

// Prevent back button after logout
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies

// Check if user is logged in
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Fetch classes with department name
$sql = "SELECT classes.id, class_name AS class_name, departments.name AS department_name, classes.created_at 
        FROM classes 
        LEFT JOIN departments ON classes.department_id = departments.id";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Classes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<?php include 'admin_header_info.php'; ?> 
    <?php include 'admin_sidebar.php'; ?> <!-- Reuse your navbar -->

    <div class="container mt-5">
        <h2 class="mb-4">Manage Classes</h2>
        <a href="add_class.php" class="btn btn-primary mb-3">Add New Class</a>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Class Name</th>
                    <th>Department</th>
                    <th>Date Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $count = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                            <td>{$count}</td>
                            <td>{$row['class_name']}</td>
                            <td>{$row['department_name']}</td>
                            <td>{$row['created_at']}</td>
                            <td>
                                <a href='edit_class.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                                <a href='delete_class.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this class?\")'>Delete</a>
                            </td>
                          </tr>";
                    $count++;
                }
                ?>
            </tbody>
        </table>
    </div>

    <?php include 'admin_footer.php'; ?> <!-- Footer -->

