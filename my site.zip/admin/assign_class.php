<?php
include '../includes/db.php';
session_start();

// 1. Get student ID and fetch student
if (!isset($_GET['id'])) {
    header('Location: manage_students.php');
    exit;
}
$student_id = (int)$_GET['id'];

$stmt = $conn->prepare("SELECT fullname, matric_no FROM students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
if (!$student) {
    $_SESSION['error'] = "Student not found.";
    header('Location: manage_students.php');
    exit;
}

// 2. Handle form submission
$success = $error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Delete previous assignments
    $del = $conn->prepare("DELETE FROM student_classes WHERE student_id = ?");
    $del->bind_param("i", $student_id);
    $del->execute();

    // Insert new assignments
    if (!empty($_POST['class_ids'])) {
        $ins = $conn->prepare("INSERT INTO student_classes (student_id, class_id) VALUES (?, ?)");
        foreach ($_POST['class_ids'] as $class_id) {
            $cid = (int)$class_id;
            $ins->bind_param("ii", $student_id, $cid);
            $ins->execute();
        }
    }
    $success = "Classes assigned successfully.";
    header("Location: manage_student.php");
}

// 3. Fetch all classes
$classes = $conn->query("SELECT id, name FROM classes ORDER BY name");

// 4. Fetch assigned class IDs
$assigned = [];
$res = $conn->prepare("SELECT class_id FROM student_classes WHERE student_id = ?");
$res->bind_param("i", $student_id);
$res->execute();
$rows = $res->get_result();
while ($r = $rows->fetch_assoc()) {
    $assigned[] = $r['class_id'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Assign Classes</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'admin_header_info.php'; ?>
<?php include 'admin_sidebar.php'; ?>

<div class="container mt-5">
  <div class="card shadow">
    <div class="card-header bg-primary text-white">
      <h5 class="mb-0">Assign Classes to <?= htmlspecialchars($student['fullname']) ?> (<?= htmlspecialchars($student['matric_no']) ?>)</h5>
    </div>
    <div class="card-body">

      <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
      <?php endif; ?>

      <form method="post">
        <div class="mb-3">
          <label class="form-label">Select Classes</label>
          <?php while ($cls = $classes->fetch_assoc()): ?>
            <div class="form-check">
              <input 
                class="form-check-input" 
                type="checkbox" 
                name="class_ids[]" 
                value="<?= $cls['id'] ?>" 
                id="class_<?= $cls['id'] ?>"
                <?= in_array($cls['id'], $assigned) ? 'checked' : '' ?>>
              <label class="form-check-label" for="class_<?= $cls['id'] ?>">
                <?= htmlspecialchars($cls['name']) ?>
              </label>
            </div>
          <?php endwhile; ?>
        </div>

        <button type="submit" class="btn btn-success">Save Assignments</button>
        <a href="manage_student.php" class="btn btn-secondary">Back to Students</a>
      </form>
    </div>
  </div>
</div>

<?php include 'admin_footer.php'; ?>
</body>
</html>
