<?php
// admin/delete_student.php
session_start();
require_once "../includes/db.php";

// Only admins allowed
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Check if student ID is provided
if (isset($_GET['id'])) {
    $student_id = $_GET['id'];
    
    // First, delete the student's subject assignments
    $conn->query("DELETE FROM student_subjects WHERE student_id = $student_id");

    // Then, delete the student from the students table
    $delete_query = "DELETE FROM students WHERE id = $student_id";
    
    if ($conn->query($delete_query)) {
        // Redirect to manage students page after successful deletion
        header("Location: manage_student.php");
        exit();
    } else {
        // If there's an error during deletion, show an error message
        echo "Error deleting student: " . $conn->error;
    }
} else {
    // If no student ID is provided, redirect to manage students page
    header("Location: manage_student.php");
    exit();
}
?>
