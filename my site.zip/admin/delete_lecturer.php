<?php
// admin/delete_lecturer.php
include '../includes/db.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $delete = mysqli_query($conn, "DELETE FROM users WHERE id = '$id' AND role = 'instructor'");
    if ($delete) {
        $_SESSION['success'] = "Lecturer deleted successfully.";
    } else {
        $_SESSION['error'] = "Failed to delete lecturer.";
    }
}

header("Location: manage_lecturer.php");
exit();
?>
