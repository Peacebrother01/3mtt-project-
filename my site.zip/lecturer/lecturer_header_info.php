<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <!-- jQuery and Bootstrap JS (for collapsible sidebar menu) -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        body {
            padding-top: 50px;
        }
        .sidebar {
            height: 100vh;
            position: fixed;
            left: 0;
            top: 56px;
            width: 220px;
            background-color: #f8f9fa;
            padding-top: 20px;
        }
        .container {
            margin-left: 220px;
            padding: 20px;
        }
    </style>
</head>
<body>

<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}
$admin_name = isset($_SESSION['user']['full_name']) ? $_SESSION['user']['full_name'] : 'Admin';
?>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">E-Learning (Lecturer)</a>
        <div class="d-flex ms-auto text-white align-items-center">
            <span class="me-3">Welcome, <?= htmlspecialchars($admin_name); ?></span>
            <a href="../logout.php" class="btn btn-sm btn-outline-light">Logout</a>
        </div>
    </div>
</nav>