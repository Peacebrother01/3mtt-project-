<?php
// db.php

$host = 'localhost';       // Usually localhost
$dbname = 'elearn_db';  // Your database name
$username = 'root';        // Your MySQL username (default in XAMPP is 'root')
$password = '';            // Your MySQL password (empty by default in XAMPP)

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
