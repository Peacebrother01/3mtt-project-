<?php
session_start();
require_once "../includes/db.php";

// Only admins allowed
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Get classes and subjects for dropdowns
$classesResult = $conn->query("SELECT id, class_name FROM classes");
$subjectsResult = $conn->query("SELECT id, name FROM subjects");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form values
    $title = $_POST['title'];
    $description = $_POST['description'];
    $class_id = $_POST['class_id'];
    $subject_id = $_POST['subject_id'];
    $file = $_FILES['file'];

    // Validate fields
    if (empty($title) || empty($description) || empty($class_id) || empty($subject_id) || empty($file)) {
        $error = "All fields are required.";
    } else {
        // Handle file upload
        $fileName = basename($file['name']);
        $targetDir = "../uploads/lectures/";
        $targetFilePath = $targetDir . $fileName;

        if (move_uploaded_file($file['tmp_name'], $targetFilePath)) {
            // Insert the lecture into the database
            $stmt = $conn->prepare("INSERT INTO lectures (title, description, class_id, subject_id, file_path, file_type, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $fileType = pathinfo($fileName, PATHINFO_EXTENSION);
            $uploadedBy = $_SESSION['user']['id']; // Assuming user ID is stored in the session
            $stmt->bind_param("ssiiisi", $title, $description, $class_id, $subject_id, $fileName, $fileType, $uploadedBy);
            
            if ($stmt->execute()) {
                $success = "Lecture added successfully!";
                header("Location: manage_lectures.php");
            } else {
                $error = "There was an error uploading the lecture.";
                header("Location: manage_lectures.php");
            }
        } else {
            $error = "Error uploading the file.";
            header("Location: manage_lectures.php");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Add New Lecture</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>

<?php include 'admin_header_info.php'; ?>

<body>
<?php include 'admin_sidebar.php'; ?>

  <div class="container mt-5">
    <h2 class="mb-4">Add New Lecture</h2>

    <!-- Display success or error message -->
    <?php if (isset($success)): ?>
      <div class="alert alert-success"><?= $success ?></div>
    <?php elseif (isset($error)): ?>
      <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
      <div class="mb-3">
        <label for="title" class="form-label">Lecture Title</label>
        <input type="text" class="form-control" id="title" name="title" required>
      </div>
      
      <div class="mb-3">
        <label for="description" class="form-label">Description</label>
        <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
      </div>

      <div class="mb-3">
        <label for="class_id" class="form-label">Class</label>
        <select class="form-select" id="class_id" name="class_id" required>
          <option value="">Select Class</option>
          <?php while ($class = $classesResult->fetch_assoc()): ?>
            <option value="<?= $class['id'] ?>"><?= $class['class_name'] ?></option>
          <?php endwhile; ?>
        </select>
      </div>

      <div class="mb-3">
        <label for="subject_id" class="form-label">Subject</label>
        <select class="form-select" id="subject_id" name="subject_id" required>
          <option value="">Select Subject</option>
          <?php while ($subject = $subjectsResult->fetch_assoc()): ?>
            <option value="<?= $subject['id'] ?>"><?= $subject['name'] ?></option>
          <?php endwhile; ?>
        </select>
      </div>

      <div class="mb-3">
        <label for="file" class="form-label">Upload File</label>
        <input type="file" class="form-control" id="file" name="file" required>
      </div>

      <button type="submit" class="btn btn-primary">Upload Lecture</button>
      <a href="manage_lectures.php" class="btn btn-secondary ms-2">Cancel</a>
    </form>
    <br/><br/><br/><br/><br/>
  </div>
  <?php include 'admin_footer.php'; ?>
