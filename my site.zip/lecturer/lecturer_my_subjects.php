<?php
session_start();
require_once '../includes/db.php';

// Ensure user is logged in and is a lecturer
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

$lecturer_id = $_SESSION['user']['id'];

// Fetch subjects assigned to the lecturer
$sql = "
    SELECT s.id, s.name AS subject_name, d.name AS department_name
    FROM subjects s
    JOIN departments d ON s.department_id = d.id
    WHERE s.lecturer_id = $lecturer_id
";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Subjects</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<?php include 'lecturer_header_info.php'; ?>

<div class="container mt-5">
    <h3>📘 My Subjects</h3>
    <table class="table table-bordered mt-4">
        <thead>
            <tr>
                <th>Subject Name</th>
                <th>Department</th>
                <th>View Students</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= htmlspecialchars($row['subject_name']) ?></td>
                    <td><?= htmlspecialchars($row['department_name']) ?></td>
                    <td>
                        <a href="lecturer_subject_students.php?subject_id=<?= $row['id'] ?>" class="btn btn-primary btn-sm">
                            View Students
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>
