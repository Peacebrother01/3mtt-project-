<?php
session_start();
require_once "../includes/db.php";

// Redirect if not a lecturer
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

$lecturer_id = $_SESSION['user']['id'];

// Fetch assignments uploaded by this lecturer
$query = "
    SELECT 
      a.id, a.title, a.deadline, a.created_at,
      s.name AS subject_name,
      c.class_name
    FROM assignments a
    JOIN subjects s   ON a.subject_id = s.id
    JOIN classes c    ON a.class_id = c.id
    WHERE a.lecturer_id = $lecturer_id
    ORDER BY a.created_at DESC
";

$result = $conn->query($query);
$assignments = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Assignments</title>
  
<?php include "lecturer_header_info.php"; ?>
<?php include "lecturer_sidebar.php"; ?>

<div class="container mt-4">
    <h2 class="mb-4">Manage Assignments</h2>

    <a href="lecturer_add_assignment.php" class="btn btn-success mb-3">
      <i class="fas fa-plus"></i> Add New Assignment
    </a>

    <?php if (empty($assignments)): ?>
        <div class="alert alert-info">No assignments found.</div>
    <?php else: ?>
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>Title</th>
                    <th>Subject</th>
                    <th>Class</th>
                    <th>Deadline</th>
                    <th>Uploaded At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($assignments as $a): ?>
                    <tr>
                        <td><?= htmlspecialchars($a['title']) ?></td>
                        <td><?= htmlspecialchars($a['subject_name']) ?></td>
                        <td><?= htmlspecialchars($a['class_name']) ?></td>
                        <td><?= date("d M Y", strtotime($a['deadline'])) ?></td>
                        <td><?= date("d M Y H:i", strtotime($a['created_at'])) ?></td>
                        <td>
                          <a href="lecturer_edit_assignment.php?id=<?= $a['id'] ?>"
                             class="btn btn-primary btn-sm">Edit</a>
                          <a href="lecturer_delete_assignment.php?id=<?= $a['id'] ?>"
                             class="btn btn-danger btn-sm"
                             onclick="return confirm('Delete this assignment?');">
                            Delete
                          </a>
                          <a href="lecturer_view_submission.php?assignment_id=<?= $a['id'] ?>" 
                            class="btn btn-sm btn-secondary">Submissions</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>
