<?php
session_start();
require_once "../includes/db.php";

// Redirect if not logged in as lecturer
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

$lecturer_id = $_SESSION['user']['id'];

// Get students and lecturers (excluding self)
$studentsResult = $conn->query("SELECT id, full_name FROM users WHERE role = 'student'");
$lecturersResult = $conn->query("SELECT id, full_name FROM users WHERE role = 'instructor' AND id != $lecturer_id");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Send Message</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h3>Send Message</h3>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-info"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
    <?php endif; ?>

    <form action="lecturer_send_message_process.php" method="post">
        <div class="form-group">
            <label for="receiver_id">Select Receiver</label>
            <select name="receiver_id" class="form-control" required>
                <option value="">-- Select a user --</option>
                <optgroup label="Students">
                    <?php while ($student = $studentsResult->fetch_assoc()): ?>
                        <option value="<?= $student['id'] ?>"><?= $student['full_name'] ?></option>
                    <?php endwhile; ?>
                </optgroup>
                <optgroup label="Lecturers">
                    <?php while ($lecturer = $lecturersResult->fetch_assoc()): ?>
                        <option value="<?= $lecturer['id'] ?>"><?= $lecturer['full_name'] ?></option>
                    <?php endwhile; ?>
                </optgroup>
            </select>
        </div>

        <div class="form-group">
            <label for="subject">Subject</label>
            <input type="text" name="subject" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="message">Message</label>
            <textarea name="message" class="form-control" rows="5" required></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Send Message</button>
    </form>
</div>

</body>
</html>
