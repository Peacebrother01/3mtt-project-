<?php
// admin/manage_lecturer.php
session_start();
require_once '../includes/db.php';

// Redirect if not logged in as admin
if (
    ! isset($_SESSION['user']) ||
    ! is_array($_SESSION['user']) ||
    ($_SESSION['user']['role'] ?? '') !== 'admin'
) {
    header('Location: ../login.php');
    exit();
}

// Fetch all instructors
$sql    = "SELECT * FROM users WHERE role = 'instructor' ORDER BY created_at DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Lecturers</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<?php include 'admin_header_info.php'; ?>
  <?php include 'admin_sidebar.php'; ?>

  <div class="container mt-5">
    <h2 class="mb-4">Manage Lecturer Users</h2>

    <?php if (!empty($_SESSION['success'])): ?>
      <div class="alert alert-success">
        <?= $_SESSION['success']; unset($_SESSION['success']); ?>
      </div>
    <?php endif; ?>

    <?php if (!empty($_SESSION['error'])): ?>
      <div class="alert alert-danger">
        <?= $_SESSION['error']; unset($_SESSION['error']); ?>
      </div>
    <?php endif; ?>

    <a href="add_lecturer.php" class="btn btn-primary mb-3">
      <i class="fas fa-user-plus"></i> Add New Lecturer
    </a>

    <table class="table table-bordered table-hover">
      <thead class="thead-dark">
        <tr>
          <th>#</th>
          <th>Full Name</th>
          <th>Email</th>
          <th>Date Registered</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $i = 1; while ($row = mysqli_fetch_assoc($result)): ?>
          <tr>
            <td><?= $i++; ?></td>
            <td><?= htmlspecialchars($row['full_name']); ?></td>
            <td><?= htmlspecialchars($row['email']); ?></td>
            <td><?= htmlspecialchars($row['created_at']); ?></td>
            <td>
              <a href="edit_lecturer.php?id=<?= $row['id']; ?>" class="btn btn-sm btn-warning">
                <i class="fas fa-edit"></i> Edit
              </a>
              <a href="delete_lecturer.php?id=<?= $row['id']; ?>"
                 class="btn btn-sm btn-danger"
                 onclick="return confirm('Are you sure you want to delete this lecturer?')">
                <i class="fas fa-trash"></i> Delete
              </a>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>

  <?php include 'admin_footer.php'; ?>
 
