<?php
// lecturer_add_assignment.php
session_start();
require_once "../includes/db.php";

// Redirect if not a lecturer
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

$lecturer_id = $_SESSION['user']['id'];

// Fetch subjects that this lecturer teaches
$stmt = $conn->prepare("SELECT id, name FROM subjects WHERE lecturer_id = ?");
$stmt->bind_param("i", $lecturer_id);
$stmt->execute();
$subjectsResult = $stmt->get_result();

// Fetch all classes
$classResult = $conn->query("SELECT id, class_name FROM classes");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add New Assignment</title>
  
<?php include 'lecturer_header_info.php'; ?>

<body>
<div class="container-fluid">
  <div class="row">
    <?php include 'lecturer_sidebar.php'; ?>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
      <h2 class="mb-4">Create New Assignment</h2>

      <?php if (!empty($_SESSION['message'])): ?>
        <div class="alert alert-info">
          <?= $_SESSION['message']; unset($_SESSION['message']); ?>
        </div>
      <?php endif; ?>

      <form method="post" enctype="multipart/form-data" class="card p-4 shadow-sm">
        <div class="row g-3">
          <div class="col-md-6">
            <label for="subject_id" class="form-label">Subject</label>
            <select id="subject_id" name="subject_id" class="form-select" required>
              <option value="">-- Select Subject --</option>
              <?php while ($sub = $subjectsResult->fetch_assoc()): ?>
                <option value="<?= $sub['id'] ?>"><?= htmlspecialchars($sub['name']) ?></option>
              <?php endwhile; ?>
            </select>
          </div>

          <div class="col-md-6">
            <label for="class_id" class="form-label">Class</label>
            <select id="class_id" name="class_id" class="form-select" required>
              <option value="">-- Select Class --</option>
              <?php while ($cls = $classResult->fetch_assoc()): ?>
                <option value="<?= $cls['id'] ?>"><?= htmlspecialchars($cls['class_name']) ?></option>
              <?php endwhile; ?>
            </select>
          </div>

          <div class="col-12">
            <label for="title" class="form-label">Assignment Title</label>
            <input type="text" id="title" name="title" class="form-control" required>
          </div>

          <div class="col-12">
            <label for="description" class="form-label">Description</label>
            <textarea id="description" name="description" class="form-control" rows="4"></textarea>
          </div>

          <div class="col-md-6">
            <label for="deadline" class="form-label">Deadline</label>
            <input type="date" id="deadline" name="deadline" class="form-control" required>
          </div>

          <div class="col-md-6">
            <label for="assignment_file" class="form-label">File (optional)</label>
            <input type="file" id="assignment_file" name="assignment_file" class="form-control">
          </div>

          <div class="col-12 text-end">
            <button type="submit" class="btn btn-primary">Create Assignment</button>
            <a href="lecturer_manage_assignment.php" class="btn btn-secondary ms-2">Cancel</a>
          </div>
        </div>
      </form>
    </main>
  </div>
</div>

<?php
// Handle form submission below the HTML to keep the structure clean
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject_id  = $_POST['subject_id'];
    $class_id    = $_POST['class_id'];
    $title       = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $deadline    = $_POST['deadline'];
    $file_path   = '';

    if (!empty($_FILES['assignment_file']['name'])) {
        $upload_dir  = '../uploads/assignments/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        $filename    = time() . '_' . basename($_FILES['assignment_file']['name']);
        $file_path   = $upload_dir . $filename;
        move_uploaded_file($_FILES['assignment_file']['tmp_name'], $file_path);
    }

    $stmt = $conn->prepare("
        INSERT INTO assignments (lecturer_id, subject_id, class_id, title, description, file_path, deadline, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    $stmt->bind_param(
      "iiissss",
      $lecturer_id,
      $subject_id,
      $class_id,
      $title,
      $description,
      $file_path,
      $deadline
    );

    if ($stmt->execute()) {
        $_SESSION['message'] = "Assignment created successfully.";
        header("Location: lecturer_manage_assignment.php");
        exit();
    } else {
        $_SESSION['message'] = "Error: " . $stmt->error;
        header("Location: lecturer_add_assignment.php");
        exit();
    }
}
?>

</body>
</html>
