<?php
// admin/add_student.php
session_start();
require_once "../includes/db.php";

// Only admins allowed
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Fetch classes, departments, and subjects
$classes = $conn->query("SELECT id, class_name FROM classes");
$departments = $conn->query("SELECT id, name FROM departments");
$subjects = $conn->query("SELECT id, name FROM subjects");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $matric_number = trim($_POST['matric_number']);
    $gender = $_POST['gender'];
    $class_id = $_POST['class_id'];
    $department_id = $_POST['department_id'];
    $status = $_POST['status'];
    $selected_subjects = $_POST['subjects']; // Array of subject IDs

    // Insert into students table
    $stmt = $conn->prepare("INSERT INTO students (name, matric_number, gender, class_id, department_id, status) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssdis", $name, $matric_number, $gender, $class_id, $department_id, $status);
    if ($stmt->execute()) {
        $student_id = $stmt->insert_id;

        // Assign subjects to the student
        if (!empty($selected_subjects)) {
            foreach ($selected_subjects as $subject_id) {
                $conn->query("INSERT INTO student_subjects (student_id, subject_id) VALUES ($student_id, $subject_id)");
            }
        }

        $success = "Student added successfully.";
    } else {
        $error = "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Add Student</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
</head>
<body>

<?php include 'admin_header_info.php'; ?>

<div class="container-fluid">
  <div class="row">
    <?php include 'admin_sidebar.php'; ?>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Add New Student</h1>
      </div>

      <?php if (isset($success)): ?>
        <div class="alert alert-success"><?= $success ?></div>
      <?php elseif (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
      <?php endif; ?>

      <form method="POST" class="card p-4 shadow-sm">
        <div class="mb-3">
          <label class="form-label">Full Name</label>
          <input type="text" name="name" class="form-control" required />
        </div>

        <div class="mb-3">
          <label class="form-label">Matric Number</label>
          <input type="text" name="matric_number" class="form-control" required />
        </div>

        <div class="mb-3">
          <label class="form-label">Gender</label>
          <select name="gender" class="form-select" required>
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Class</label>
          <select name="class_id" class="form-select" required>
            <option value="">Select Class</option>
            <?php while ($class = $classes->fetch_assoc()): ?>
              <option value="<?= $class['id'] ?>"><?= $class['class_name'] ?></option>
            <?php endwhile; ?>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Department</label>
          <select name="department_id" class="form-select" required>
            <option value="">Select Department</option>
            <?php while ($department = $departments->fetch_assoc()): ?>
              <option value="<?= $department['id'] ?>"><?= $department['name'] ?></option>
            <?php endwhile; ?>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Subjects</label>
          <div class="form-check">
            <?php while ($subject = $subjects->fetch_assoc()): ?>
              <input type="checkbox" class="form-check-input" name="subjects[]" value="<?= $subject['id'] ?>" id="subject_<?= $subject['id'] ?>" />
              <label class="form-check-label" for="subject_<?= $subject['id'] ?>"><?= $subject['name'] ?></label><br />
            <?php endwhile; ?>
          </div>
        </div>

        <div class="mb-3">
          <label class="form-label">Status</label>
          <select name="status" class="form-select" required>
            <option value="inactive">Inactive</option>
            <option value="active">Active</option>
            <option value="suspended">Suspended</option>
          </select>
        </div>

        <button type="submit" class="btn btn-primary">
          <i class="fas fa-save"></i> Save Student
        </button>
      </form>
    </main>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
