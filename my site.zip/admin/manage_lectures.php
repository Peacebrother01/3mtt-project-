<?php
// admin/manage_lectures.php
session_start();
require_once "../includes/db.php";

// Only admins allowed
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Fetch all lectures with class, subject, and lecturer info
$result = $conn->query("
    SELECT 
        lectures.id, 
        lectures.title, 
        lectures.description, 
        lectures.file_path, 
        lectures.file_type,
        lectures.created_at,
        classes.class_name, 
        subjects.name AS subject_name, 
        users.full_name AS lecturer_name 
    FROM lectures 
    LEFT JOIN classes   ON lectures.class_id = classes.id 
    LEFT JOIN subjects  ON lectures.subject_id = subjects.id 
    LEFT JOIN users     ON lectures.uploaded_by = users.id
    ORDER BY lectures.created_at DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Manage Lectures</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>

<?php include 'admin_header_info.php'; ?>

<body>
<?php include 'admin_sidebar.php'; ?>
  <div class="container mt-5">
    <h2 class="mb-4">Manage Lectures</h2>

    <!-- Add New Lecture Button -->
    <a href="add_lectures.php" class="btn btn-success mb-3"><i class="fas fa-plus"></i> Add New Lecture</a>

    <!-- Search Form -->
    <form method="GET" class="mb-3">
      <div class="input-group">
        <input type="text" name="search" class="form-control" placeholder="Search lectures..." value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
        <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i> Search</button>
      </div>
    </form>

    <!-- Table for Lectures -->
    <table class="table table-bordered table-striped">
      <thead class="table-dark">
        <tr>
          <th>Title</th>
          <th>Description</th>
          <th>Class</th>
          <th>Subject</th>
          <th>Lecturer</th>
          <th>File</th>
          <th>Type</th>
          <th>Uploaded At</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()) : ?>
          <tr>
            <td><?= htmlspecialchars($row['title']) ?></td>
            <td><?= htmlspecialchars($row['description']) ?></td>
            <td><?= htmlspecialchars($row['class_name']) ?></td>
            <td><?= htmlspecialchars($row['subject_name']) ?></td>
            <td><?= htmlspecialchars($row['lecturer_name']) ?></td>
            <td><a href="../uploads/<?= $row['file_path'] ?>" target="_blank">View</a></td>
            <td><?= htmlspecialchars($row['file_type']) ?></td>
            <td><?= htmlspecialchars($row['created_at']) ?></td>
            <td>
              <a href="edit_lectures.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
              <a href="delete_lecture.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this lecture?')">Delete</a>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
  <?php include 'admin_footer.php'; ?>
