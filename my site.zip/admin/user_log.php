<?php
// dashboard/manage_user_log.php
include '../includes/db.php';
session_start();

// Prevent back button after logout
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies

// Check if user is logged in
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Fetch logs: user name, date, and time spent
$sql = "
  SELECT 
    ul.id,
    u.full_name,
    DATE(ul.login_time)            AS session_date,
    TIMEDIFF(ul.logout_time, ul.login_time) AS time_spent
  FROM user_logs ul
  JOIN users      u ON ul.user_id = u.id
  ORDER BY ul.login_time DESC
";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin User Log</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

<?php include 'admin_header_info.php'; ?>
<?php include 'admin_sidebar.php'; ?>

<div class="container-fluid p-4">
  <h2 class="mb-4">Admin User Log</h2>
  
  <?php if (mysqli_num_rows($result) === 0): ?>
    <div class="alert alert-info">No log entries found.</div>
  <?php else: ?>
    <table class="table table-bordered table-hover">
      <thead class="table-dark">
        <tr>
          <th>#</th>
          <th>User Name</th>
          <th>Date</th>
          <th>Time Spent</th>
        </tr>
      </thead>
      <tbody>
        <?php $sn = 1; while ($row = mysqli_fetch_assoc($result)): ?>
        <tr>
          <td><?= $sn++ ?></td>
          <td><?= htmlspecialchars($row['full_name']) ?></td>
          <td><?= $row['session_date'] ?></td>
          <td><?= $row['time_spent'] ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?php include 'admin_footer.php'; ?>

<!-- Bootstrap JS (Optional but needed for some components like modals) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
