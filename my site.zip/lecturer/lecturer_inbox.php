<?php
session_start();
require_once "../includes/db.php";

// Redirect if not a lecturer
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

$lecturer_id = $_SESSION['user']['id'];

// Mark message as read if requested
if (isset($_GET['read_id'])) {
    $read_id = intval($_GET['read_id']);
    $conn->query("UPDATE messages SET is_read = 1 WHERE id = $read_id AND receiver_id = $lecturer_id");
}

// Fetch inbox messages
$sql = "SELECT m.id, m.subject, m.message, m.created_at, m.is_read, u.full_name AS sender_name 
        FROM messages m
        JOIN users u ON m.sender_id = u.id
        WHERE m.receiver_id = $lecturer_id
        ORDER BY m.created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inbox</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<?php include 'lecturer_header_info.php'; ?>

<body>
<div class="container mt-5">
    <h3>Inbox</h3>

    <?php if ($result->num_rows > 0): ?>
        <table class="table table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>From</th>
                    <th>Subject</th>
                    <th>Message</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr class="<?= $row['is_read'] ? '' : 'table-warning' ?>">
                        <td><?= htmlspecialchars($row['sender_name']) ?></td>
                        <td><?= htmlspecialchars($row['subject']) ?></td>
                        <td><?= htmlspecialchars(substr($row['message'],0,50)) ?>…</td>
                        <td><?= date("d M Y, H:i", strtotime($row['created_at'])) ?></td>
                        <td><?= $row['is_read'] ? 'Read' : 'Unread' ?></td>
                        <td>
                          <!-- View/Read button -->
                          <a href="lecturer_read_message.php?id=<?= $row['id'] ?>" 
                             class="btn btn-sm btn-info">Read</a>

                          <!-- Mark as Read button -->
                          <?php if (!$row['is_read']): ?>
                            <a href="lecturer_inbox.php?read_id=<?= $row['id'] ?>" 
                               class="btn btn-sm btn-primary">Mark as Read</a>
                          <?php else: ?>
                            <span class="text-success">✔</span>
                          <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="alert alert-info">No messages yet.</div>
    <?php endif; ?>
</div>
</body>
</html>
