<?php
// admin/manage_student.php
session_start();
require_once "../includes/db.php";

// Only admins allowed
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Fetch all students with their associated classes and subjects
$result = $conn->query("
    SELECT students.id, 
           students.name, 
           students.matric_number, 
           students.gender, 
           students.status, 
           classes.class_name, 
           GROUP_CONCAT(subjects.name) AS subjects
    FROM students
    LEFT JOIN classes ON students.class_id = classes.id
    LEFT JOIN student_subjects ON students.id = student_subjects.student_id
    LEFT JOIN subjects ON student_subjects.subject_id = subjects.id
    GROUP BY students.id
    ORDER BY students.name ASC
");

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Manage Students</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
</head>
<body>

<?php include 'admin_header_info.php'; ?>

<div class="container-fluid">
  <div class="row">
    <?php include 'admin_sidebar.php'; ?>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Manage Students</h1>
        <a href="add_student.php" class="btn btn-primary">
          <i class="fas fa-plus"></i> Add New Student
        </a>
      </div>

      <?php if ($result->num_rows > 0): ?>
        <div class="table-responsive">
          <table class="table table-striped table-bordered align-middle">
            <thead class="table-dark">
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Matric Number</th>
                <th>Gender</th>
                <th>Class</th>
                <th>Subjects</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php $sn = 1; ?>
              <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                  <td><?= $sn++ ?></td>
                  <td><?= htmlspecialchars($row['name']) ?></td>
                  <td><?= htmlspecialchars($row['matric_number']) ?></td>
                  <td><?= htmlspecialchars($row['gender']) ?></td>
                  <td><?= htmlspecialchars($row['class_name']) ?></td>
                  <td><?= htmlspecialchars($row['subjects']) ?></td>
                  <td><?= ucfirst(htmlspecialchars($row['status'])) ?></td>
                  <td>
                    <a href="edit_student.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">
                      <i class="fas fa-edit"></i>
                    </a>
                    <a href="delete_student.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger"
                       onclick="return confirm('Are you sure you want to delete this student?')">
                      <i class="fas fa-trash"></i>
                    </a>
                  </td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <div class="alert alert-info">No students found.</div>
      <?php endif; ?>
    </main>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
