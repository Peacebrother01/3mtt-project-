<!-- Sidebar -->
<div class="sidebar border-end">
    <ul class="nav flex-column">
        <li class="nav-item"><a class="nav-link" href="lecturer_dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="lecturer_manage_lectures.php"><i class="fas fa-upload"></i> Manage Lectures</a></li>
        <li class="nav-item"><a class="nav-link" href="lecturer_manage_assignment.php"><i class="fas fa-tasks"></i> Assignments</a></li>
     
        <li class="nav-item"><a class="nav-link" href="#"><i class="fas fa-users"></i> My Students</a></li>
        <li class="nav-item"><a class="nav-link" href="lecturer_my_subjects.php"><i class="fas fa-user-cog"></i> My Classes</a></li>
        <li class="nav-item">
    <a class="nav-link" data-toggle="collapse" href="#messageMenu" role="button" aria-expanded="false" aria-controls="messageMenu">
        💬 Messages
    </a>
    <div class="collapse" id="messageMenu">
        <ul class="list-unstyled pl-3">
            <li><a class="nav-link" href="lecturer_inbox.php">📥 Inbox</a></li>
            <li><a class="nav-link" href="lecturer_sent_messages.php">📤 Sent</a></li>
            <li><a class="nav-link" href="lecturer_send_message.php">✉️ Compose</a></li>
        </ul>
    </div>
</li>
    </ul>
</div>