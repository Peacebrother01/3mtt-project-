<?php
// lecturer_manage_lectures.php
session_start();
require_once "../includes/db.php";

// Redirect if not a lecturer
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

$lecturer_id = $_SESSION['user']['id'];

// Get subjects assigned to this lecturer
$subjectResult = $conn->query("SELECT subject_id FROM lecturer_subjects WHERE lecturer_id = $lecturer_id");

$subject_ids = [];
while ($row = $subjectResult->fetch_assoc()) {
    $subject_ids[] = $row['subject_id'];
}

// Convert subject IDs to a string for SQL IN clause
$subject_id_list = implode(',', $subject_ids);

// Fetch lectures for subjects assigned to this lecturer
$lectures = [];
if (!empty($subject_id_list)) {
    $lectureQuery = "
        SELECT 
            lectures.id,
            lectures.title,
            lectures.description,
            lectures.file_path,
            lectures.file_type,
            lectures.created_at,
            classes.class_name,
            subjects.name AS subject_name,
            users.full_name AS uploader_name
        FROM lectures
        LEFT JOIN classes ON lectures.class_id = classes.id
        LEFT JOIN subjects ON lectures.subject_id = subjects.id
        LEFT JOIN users ON lectures.uploaded_by = users.id
        WHERE lectures.subject_id IN ($subject_id_list)
        ORDER BY lectures.created_at DESC
    ";

    $result = $conn->query($lectureQuery);
    while ($row = $result->fetch_assoc()) {
        $lectures[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Lectures</title>
  

<?php include 'lecturer_header_info.php'; ?>
<?php include 'lecturer_sidebar.php'; ?>


<div class="container mt-5">
    <h2 class="mb-4">Manage Lectures</h2>

    <!-- Add Lecture Button -->
    <a href="lecturer_add_lecture.php" class="btn btn-success mb-3">
        <i class="fas fa-plus"></i> Add New Lecture
    </a>

    <!-- Lecture Table -->
    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>Title</th>
                <th>Description</th>
                <th>Class</th>
                <th>Subject</th>
                <th>File</th>
                <th>Uploaded By</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($lectures)): ?>
                <tr>
                    <td colspan="7" class="text-center">No lectures found.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($lectures as $lecture): ?>
                    <tr>
                        <td><?= htmlspecialchars($lecture['title']) ?></td>
                        <td><?= htmlspecialchars($lecture['description']) ?></td>
                        <td><?= htmlspecialchars($lecture['class_name']) ?></td>
                        <td><?= htmlspecialchars($lecture['subject_name']) ?></td>
                        <td>
                            <?php if ($lecture['file_path']): ?>
                                <a href="../uploads/<?= htmlspecialchars($lecture['file_path']) ?>" target="_blank">View</a>
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($lecture['uploader_name']) ?></td>
                        <td>
                            <a href="lecturer_edit_lecture.php?id=<?= $lecture['id'] ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <a href="lecturer_delete_lecture.php?id=<?= $lecture['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                <i class="fas fa-trash"></i> Delete
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php include "lecturer_footer.php"; ?>
