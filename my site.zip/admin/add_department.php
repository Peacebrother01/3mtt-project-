<?php
include '../includes/db.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    $sql = "INSERT INTO departments (name, description) VALUES ('$name', '$description')";
    if (mysqli_query($conn, $sql)) {
        header("Location: manage_department.php");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Department</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<?php include 'admin_header_info.php'; ?>
    <?php include 'admin_sidebar.php'; ?>
    <div class="container mt-5">
        <h2>Add Department</h2>
        <form method="POST">
            <div class="form-group">
                <label>Department Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Description (optional)</label>
                <textarea name="description" class="form-control"></textarea>
            </div>
            <button type="submit" class="btn btn-success">Save</button>
            <a href="manage_department.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
    <?php include 'admin_footer.php'; ?>
