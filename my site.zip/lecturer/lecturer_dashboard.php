<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

$lecturer_name = $_SESSION['user']['full_name'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Lecturer Dashboard</title>
    
<?php include 'lecturer_header_info.php'; ?>
<?php include 'lecturer_sidebar.php'; ?>


<!-- Main Content -->
<div class="container">
    <h2>Lecturer Dashboard</h2>
    <div class="row mt-4">
        <div class="col-md-4">
            <div class="card text-white bg-primary mb-3">
                <div class="card-body">
                    <h5 class="card-title">My Subjects</h5>
                    <p class="card-text">Coming soon...</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-white bg-success mb-3">
                <div class="card-body">
                    <h5 class="card-title">My Classes</h5>
                    <p class="card-text">Coming soon...</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-white bg-info mb-3">
                <div class="card-body">
                    <h5 class="card-title">Assignments</h5>
                    <p class="card-text">Coming soon...</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include "lecturer_footer.php"; ?>
