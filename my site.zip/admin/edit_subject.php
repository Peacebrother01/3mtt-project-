<?php
include '../includes/db.php';
session_start();

// Fetch departments for the dropdown
$sql_departments = "SELECT * FROM departments";
$departments_result = mysqli_query($conn, $sql_departments);

// Fetch lecturers (users with role 'instructor')
$sql_lecturers = "SELECT * FROM users WHERE role='instructor'";
$lecturers_result = mysqli_query($conn, $sql_lecturers);

// Check if subject ID is provided and fetch subject details
if (isset($_GET['id'])) {
    $subject_id = $_GET['id'];
    $sql_subject = "SELECT * FROM subjects WHERE id = '$subject_id'";
    $subject_result = mysqli_query($conn, $sql_subject);

    if (mysqli_num_rows($subject_result) == 1) {
        $subject = mysqli_fetch_assoc($subject_result);
    } else {
        $_SESSION['message'] = 'Subject not found';
        header('Location: manage_subject.php');
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form input values
    $subject_name = mysqli_real_escape_string($conn, $_POST['subject_name']);
    $department_id = $_POST['department_id'];
    $lecturer_id = $_POST['lecturer_id'];

    // Update subject in the database
    $sql_update = "UPDATE subjects SET name = '$subject_name', department_id = '$department_id', lecturer_id = '$lecturer_id' WHERE id = '$subject_id'";

    if (mysqli_query($conn, $sql_update)) {
        $_SESSION['message'] = 'Subject updated successfully';
        header('Location: manage_subject.php');
        exit;
    } else {
        $_SESSION['message'] = 'Error updating subject';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Subject</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>

<?php include 'admin_header_info.php'; ?>
<?php include 'admin_sidebar.php'; ?>

<div class="container mt-5">
    <h2 class="mb-4">Edit Subject</h2>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-info"><?= $_SESSION['message'] ?></div>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <form action="edit_subject.php?id=<?= $subject['id'] ?>" method="POST">
        <div class="form-group">
            <label for="subject_name">Subject Name</label>
            <input type="text" class="form-control" id="subject_name" name="subject_name" value="<?= htmlspecialchars($subject['name']) ?>" required>
        </div>

        <div class="form-group">
            <label for="department_id">Department</label>
            <select class="form-control" id="department_id" name="department_id" required>
                <option value="">Select Department</option>
                <?php while ($row = mysqli_fetch_assoc($departments_result)): ?>
                    <option value="<?= $row['id'] ?>" <?= $subject['department_id'] == $row['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($row['name']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="lecturer_id">Lecturer</label>
            <select class="form-control" id="lecturer_id" name="lecturer_id" required>
                <option value="">Select Lecturer</option>
                <?php while ($row = mysqli_fetch_assoc($lecturers_result)): ?>
                    <option value="<?= $row['id'] ?>" <?= $subject['lecturer_id'] == $row['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($row['full_name']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Update Subject</button>
    </form>
</div>

<?php include 'admin_footer.php'; ?>

</html>
