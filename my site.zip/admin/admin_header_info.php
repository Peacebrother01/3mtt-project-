<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}
$admin_name = isset($_SESSION['user']['full_name']) ? $_SESSION['user']['full_name'] : 'Admin';
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">E-learning Admin</a>
    <div class="d-flex ms-auto">
      <span class="navbar-text text-white me-3">
        Welcome, <?php echo htmlspecialchars($admin_name); ?>
      </span>
      <a href="../logout.php" class="btn btn-outline-light">Logout</a>
    </div>
  </div>
</nav>
