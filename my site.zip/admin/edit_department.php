<?php
include '../includes/db.php';
session_start();

$id = $_GET['id'];
$sql = "SELECT * FROM departments WHERE id = $id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    $sql = "UPDATE departments SET name='$name', description='$description' WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        header("Location: manage_department.php");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Department</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<?php include 'admin_header_info.php'; ?>
    <?php include 'admin_sidebar.php'; ?>
    <div class="container mt-5">
        <h2>Edit Department</h2>
        <form method="POST">
            <div class="form-group">
                <label>Department Name</label>
                <input type="text" name="name" value="<?= $row['name']; ?>" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea name="description" class="form-control"><?= $row['description']; ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="manage_department.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>
