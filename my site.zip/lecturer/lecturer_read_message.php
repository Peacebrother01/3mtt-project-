<?php
// lecturer_read_message.php
session_start();
require_once "../includes/db.php";

// Redirect if not a lecturer
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

$lecturer_id = $_SESSION['user']['id'];

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: lecturer_inbox.php");
    exit();
}
$message_id = (int)$_GET['id'];

// Fetch the message details
$stmt = $conn->prepare("
    SELECT m.*, u.full_name AS sender_name
    FROM messages m
    JOIN users u ON m.sender_id = u.id
    WHERE m.id = ? AND m.receiver_id = ?
");
$stmt->bind_param("ii", $message_id, $lecturer_id);
$stmt->execute();
$result = $stmt->get_result();
$message = $result->fetch_assoc();

if (!$message) {
    $_SESSION['message'] = 'Message not found or access denied.';
    header('Location: lecturer_inbox.php');
    exit();
}

// Mark as read if unread
if (!$message['is_read']) {
    $conn->query("UPDATE messages SET is_read = 1 WHERE id = $message_id");
    $message['is_read'] = 1;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Read Message</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<?php include 'lecturer_header_info.php'; ?>
<body>
<div class="container mt-5">
  <h3>Message from <?= htmlspecialchars($message['sender_name']) ?></h3>
  <div class="card mb-4">
    <div class="card-header">
      <strong>Subject:</strong> <?= htmlspecialchars($message['subject']) ?><br>
      <small class="text-muted">Sent on <?= date("d M Y, H:i", strtotime($message['created_at'])) ?></small>
    </div>
    <div class="card-body">
      <p><?= nl2br(htmlspecialchars($message['message'])) ?></p>
    </div>
  </div>

  <!-- Reply Form -->
  <h4>Reply</h4>
  <form action="lecturer_send_message_process.php" method="post" class="card p-4 shadow-sm">
    <!-- Send back to original sender -->
    <input type="hidden" name="receiver_id" value="<?= $message['sender_id'] ?>">
    <div class="mb-3">
      <label for="reply_subject" class="form-label">Subject</label>
      <input type="text"
             id="reply_subject"
             name="subject"
             class="form-control"
             value="Re: <?= htmlspecialchars($message['subject']) ?>"
             required>
    </div>
    <div class="mb-3">
      <label for="reply_message" class="form-label">Message</label>
      <textarea id="reply_message"
                name="message"
                class="form-control"
                rows="5"
                required></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Send Reply</button>
    <br/>
    <a href="lecturer_inbox.php" class="btn btn-secondary ms-2">Back to Inbox</a>
  </form>
</div>
</body>
</html>
