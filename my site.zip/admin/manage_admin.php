<?php
include '../includes/db.php';
session_start();

// Prevent back button after logout
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies

// Check if user is logged in
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}


// Fetch admin users
$sql = "SELECT * FROM users WHERE role='admin'";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<?php include 'admin_header_info.php'; ?> <!-- Your admin navbar -->
    <?php include 'admin_sidebar.php'; ?> <!-- Your admin navbar -->
    <div class="container mt-5">
        <h2 class="mb-4">Manage Admin Users</h2>
        <a href="add_admin.php" class="btn btn-primary mb-3">Add New Admin</a>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Date Registered</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $count = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                            <td>{$count}</td>
                            <td>{$row['full_name']}</td>
                            <td>{$row['email']}</td>
                            <td>{$row['created_at']}</td>
                            <td>
                                <a href='edit_admin.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                                <a href='delete_admin.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                            </td>
                          </tr>";
                    $count++;
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php include 'admin_footer.php'; ?>