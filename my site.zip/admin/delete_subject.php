<?php
include '../includes/db.php';
session_start();

// Check if subject ID is provided
if (isset($_GET['id'])) {
    $subject_id = $_GET['id'];

    // Delete the subject from the database
    $sql_delete = "DELETE FROM subjects WHERE id = '$subject_id'";

    if (mysqli_query($conn, $sql_delete)) {
        $_SESSION['message'] = 'Subject deleted successfully';
    } else {
        $_SESSION['message'] = 'Error deleting subject';
    }
}

header('Location: manage_subject.php');
exit;
