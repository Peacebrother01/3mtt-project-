<?php
session_start();
require_once "../includes/db.php";

// Only admins allowed
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Ensure lecture ID is provided
if (!isset($_GET['id'])) {
    header("Location: manage_lectures.php");
    exit();
}

$lectureId = (int)$_GET['id'];

// Fetch classes and subjects for dropdowns
$classesResult = $conn->query("SELECT id, class_name FROM classes");
$subjectsResult = $conn->query("SELECT id, name FROM subjects");

// Fetch existing lecture data
$stmt = $conn->prepare("SELECT * FROM lectures WHERE id = ?");
$stmt->bind_param("i", $lectureId);
$stmt->execute();
$lectureResult = $stmt->get_result();
if ($lectureResult->num_rows !== 1) {
    header("Location: manage_lectures.php");
    exit();
}
$lecture = $lectureResult->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title       = $_POST['title'];
    $description = $_POST['description'];
    $class_id    = $_POST['class_id'];
    $subject_id  = $_POST['subject_id'];
    $fileName    = $lecture['file_path'];
    $fileType    = $lecture['file_type'];

    // Process new file if uploaded
    if (!empty($_FILES['file']['name'])) {
        $file       = $_FILES['file'];
        $newName    = basename($file['name']);
        $targetDir  = "../uploads/lectures/";
        $targetPath = $targetDir . $newName;
        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            // Remove old file
            if (file_exists($targetDir . $fileName)) {
                unlink($targetDir . $fileName);
            }
            $fileName = $newName;
            $fileType = pathinfo($newName, PATHINFO_EXTENSION);
        } else {
            $error = "Error uploading the new file.";
        }
    }

    // Update lecture record if no errors
    if (!isset($error)) {
        $update = $conn->prepare(
            "UPDATE lectures SET title = ?, description = ?, class_id = ?, subject_id = ?, file_path = ?, file_type = ? WHERE id = ?"
        );
        $update->bind_param(
            "ssiiisi", 
            $title, 
            $description, 
            $class_id, 
            $subject_id, 
            $fileName, 
            $fileType, 
            $lectureId
        );
        if ($update->execute()) {
            $success = "Lecture updated successfully!";
            // Refresh data
            $stmt->execute();
            $lecture = $stmt->get_result()->fetch_assoc();
        } else {
            $error = "There was an error updating the lecture.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Edit Lecture</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>

<?php include 'admin_header_info.php'; ?>

<body>
<?php include 'admin_sidebar.php'; ?>

  <div class="container mt-5">
    <h2 class="mb-4">Edit Lecture</h2>

    <!-- Display messages -->
    <?php if (isset($success)): ?>
      <div class="alert alert-success"><?= $success ?></div>
    <?php elseif (isset($error)): ?>
      <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
      <div class="mb-3">
        <label for="title" class="form-label">Lecture Title</label>
        <input type="text" class="form-control" id="title" name="title" required value="<?= htmlspecialchars($lecture['title']) ?>">
      </div>

      <div class="mb-3">
        <label for="description" class="form-label">Description</label>
        <textarea class="form-control" id="description" name="description" rows="4" required><?= htmlspecialchars($lecture['description']) ?></textarea>
      </div>

      <div class="mb-3">
        <label for="class_id" class="form-label">Class</label>
        <select class="form-select" id="class_id" name="class_id" required>
          <option value="">Select Class</option>
          <?php while ($class = $classesResult->fetch_assoc()): ?>
            <option value="<?= $class['id'] ?>" <?= ($class['id'] == $lecture['class_id']) ? 'selected' : '' ?>>
              <?= htmlspecialchars($class['class_name']) ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>

      <div class="mb-3">
        <label for="subject_id" class="form-label">Subject</label>
        <select class="form-select" id="subject_id" name="subject_id" required>
          <option value="">Select Subject</option>
          <?php while ($subject = $subjectsResult->fetch_assoc()): ?>
            <option value="<?= $subject['id'] ?>" <?= ($subject['id'] == $lecture['subject_id']) ? 'selected' : '' ?>>
              <?= htmlspecialchars($subject['name']) ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>

      <div class="mb-3">
        <label class="form-label">Current File</label>
        <div>
          <?php if ($lecture['file_path']): ?>
            <a href="../uploads/lectures/<?= htmlspecialchars($lecture['file_path']) ?>" target="_blank">
              <?= htmlspecialchars($lecture['file_path']) ?>
            </a>
          <?php else: ?>
            <span>— No file uploaded —</span>
          <?php endif; ?>
        </div>
      </div>

      <div class="mb-3">
        <label for="file" class="form-label">Replace File (optional)</label>
        <input type="file" class="form-control" id="file" name="file">
      </div>

      <button type="submit" class="btn btn-primary">Update Lecture</button>
      <a href="manage_lectures.php" class="btn btn-secondary ms-2">Cancel</a>
    </form>
    <br/><br/><br/><br/><br/>
  </div>
  <?php include 'admin_footer.php'; ?>

