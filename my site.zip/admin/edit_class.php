<?php
include '../includes/db.php';
session_start();

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM classes WHERE id=$id");
$class = mysqli_fetch_assoc($result);

$departments = mysqli_query($conn, "SELECT * FROM departments");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $class_name = $_POST['class_name'];
    $department_id = $_POST['department_id'];

    $stmt = $conn->prepare("UPDATE classes SET class_name = ?, department_id = ? WHERE id = ?");
    $stmt->bind_param("sii", $class_name, $department_id, $id);
    $stmt->execute();

    header("Location: manage_class.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Class</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<?php include 'admin_header_info.php'; ?>
    <?php include 'admin_sidebar.php'; ?>

    <div class="container mt-5">
        <h2 class="mb-4">Edit Class</h2>
        <form method="post">
            <div class="form-group">
                <label>Class Name</label>
                <input type="text" name="class_name" class="form-control" value="<?php echo $class['class_name']; ?>" required>
            </div>
            <div class="form-group">
                <label>Department</label>
                <select name="department_id" class="form-control" required>
                    <?php while ($dept = mysqli_fetch_assoc($departments)) {
                        $selected = $dept['id'] == $class['department_id'] ? 'selected' : '';
                        echo "<option value='{$dept['id']}' $selected>{$dept['name']}</option>";
                    } ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Update Class</button>
            <a href="manage_class.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <?php include 'admin_footer.php'; ?>
