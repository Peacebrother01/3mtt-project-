<?php
include '../includes/db.php';
session_start();

// Prevent back button after logout
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies

// Check if user is logged in
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Fetch all subjects with department and lecturer info
$sql = "
  SELECT 
    s.id,
    s.name            AS subject_name,
    d.name            AS department_name,
    u.full_name        AS lecturer_name,
    s.created_at
  FROM subjects s
  LEFT JOIN departments d ON s.department_id = d.id
  LEFT JOIN users u       ON s.lecturer_id   = u.id
  ORDER BY s.created_at DESC
";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Subjects</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>

<?php include 'admin_header_info.php'; ?>
<?php include 'admin_sidebar.php'; ?>

<div class="container mt-5">
    <h2 class="mb-4">Manage Subjects</h2>
    <a href="add_subject.php" class="btn btn-primary mb-3">Add New Subject</a>

    <table class="table table-bordered table-hover">
    <thead class="table-dark">
      <tr>
        <th>#</th>
        <th>Subject Name</th>
        <th>Department</th>
        <th>Lecturer</th>
        <th>Date Created</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php $i = 1; while ($row = mysqli_fetch_assoc($result)): ?>
      <tr>
        <td><?= $i++ ?></td>
        <td><?= htmlspecialchars($row['subject_name']) ?></td>
        <td><?= htmlspecialchars($row['department_name'] ?: '—') ?></td>
        <td><?= htmlspecialchars($row['lecturer_name'] ?: '—') ?></td>
        <td><?= $row['created_at'] ?></td>
        <td>
          <a href="edit_subject.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
          <a href="delete_subject.php?id=<?= $row['id'] ?>"
             class="btn btn-sm btn-danger"
             onclick="return confirm('Delete this subject?')">
            Delete
          </a>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php include 'admin_footer.php'; ?>

</html>
