<?php
include '../includes/db.php';
session_start();

// 1. Get the student ID
if (!isset($_GET['id'])) {
    header('Location: manage_students.php');
    exit;
}
$student_id = (int)$_GET['id'];

// 2. Fetch student info
$stmt = $conn->prepare("SELECT fullname, matric_no FROM students WHERE id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
if (!$student) {
    $_SESSION['error'] = "Student not found.";
    header('Location: manage_students.php');
    exit;
}

// 3. Handle form submission
$success = $error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Remove existing assignments
    $del = $conn->prepare("DELETE FROM student_subjects WHERE student_id = ?");
    $del->bind_param("i", $student_id);
    $del->execute();

    // Insert new ones
    if (!empty($_POST['subject_ids'])) {
        $ins = $conn->prepare("INSERT INTO student_subjects (student_id, subject_id) VALUES (?, ?)");
        foreach ($_POST['subject_ids'] as $subject_id) {
            $sid = (int)$subject_id;
            $ins->bind_param("ii", $student_id, $sid);
            $ins->execute();
        }
    }
    $success = "Subjects assigned successfully.";
    header("Location: manage_student.php");
}

// 4. Fetch all subjects
$subjects = $conn->query("SELECT id, name FROM subjects ORDER BY name");

// 5. Fetch already assigned subjects
$assigned = [];
$res = $conn->prepare("SELECT subject_id FROM student_subjects WHERE student_id = ?");
$res->bind_param("i", $student_id);
$res->execute();
$rows = $res->get_result();
while ($r = $rows->fetch_assoc()) {
    $assigned[] = $r['subject_id'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Assign Subjects</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include 'admin_header_info.php'; ?>
<?php include 'admin_sidebar.php'; ?>

<div class="container mt-5">
  <div class="card shadow">
    <div class="card-header bg-primary text-white">
      <h5 class="mb-0">
        Assign Subjects to <?= htmlspecialchars($student['fullname']) ?>
        <small class="text-light">(<?= htmlspecialchars($student['matric_no']) ?>)</small>
      </h5>
    </div>
    <div class="card-body">

      <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
      <?php endif; ?>

      <form method="post">
        <div class="mb-3">
          <label class="form-label">Select Subjects</label>
          <?php while ($sub = $subjects->fetch_assoc()): ?>
            <div class="form-check">
              <input 
                class="form-check-input" 
                type="checkbox" 
                name="subject_ids[]" 
                value="<?= $sub['id'] ?>" 
                id="subject_<?= $sub['id'] ?>"
                <?= in_array($sub['id'], $assigned) ? 'checked' : '' ?>>
              <label class="form-check-label" for="subject_<?= $sub['id'] ?>">
                <?= htmlspecialchars($sub['name']) ?>
              </label>
            </div>
          <?php endwhile; ?>
        </div>

        <button type="submit" class="btn btn-success">Save Assignments</button>
        <a href="manage_student.php" class="btn btn-secondary">Back to Students</a>
      </form>

    </div>
  </div>
</div>

<?php include 'admin_footer.php'; ?>
</body>
</html>
