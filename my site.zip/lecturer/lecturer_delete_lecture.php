<?php
session_start();
require_once "../includes/db.php";

// Redirect if not a lecturer
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

$lecturer_id = $_SESSION['user']['id'];

if (!isset($_GET['id'])) {
    $_SESSION['message'] = "Invalid request.";
    header("Location: lecturer_manage_lectures.php");
    exit();
}

$lecture_id = intval($_GET['id']);

// Fetch the lecture and make sure it belongs to this lecturer
$sql = "SELECT file_path FROM lectures WHERE id = ? AND uploaded_by = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $lecture_id, $lecturer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['message'] = "Lecture not found or access denied.";
    header("Location: lecturer_manage_lectures.php");
    exit();
}

$lecture = $result->fetch_assoc();
$file_path = $lecture['file_path'];

// Delete lecture record from database
$deleteStmt = $conn->prepare("DELETE FROM lectures WHERE id = ? AND uploaded_by = ?");
$deleteStmt->bind_param("ii", $lecture_id, $lecturer_id);
$deleteStmt->execute();

// Delete the file if it exists
if (file_exists($file_path)) {
    unlink($file_path);
}

$_SESSION['message'] = "Lecture deleted successfully.";
header("Location: lecturer_manage_lectures.php");
exit();
?>
