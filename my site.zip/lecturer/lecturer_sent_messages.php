<?php
session_start();
require_once "../includes/db.php";

// Redirect if not a lecturer
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

$lecturer_id = $_SESSION['user']['id'];

// Fetch sent messages
$sql = "SELECT m.subject, m.message, m.created_at, u.full_name AS receiver_name 
        FROM messages m
        JOIN users u ON m.receiver_id = u.id
        WHERE m.sender_id = $lecturer_id
        ORDER BY m.created_at DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sent Messages</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<?php include 'lecturer_header_info.php'; ?>

<body>
<div class="container mt-5">
    <h3>Sent Messages</h3>

    <?php if ($result->num_rows > 0): ?>
        <table class="table table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>To</th>
                    <th>Subject</th>
                    <th>Message</th>
                    <th>Sent On</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['receiver_name']) ?></td>
                    <td><?= htmlspecialchars($row['subject']) ?></td>
                    <td><?= htmlspecialchars($row['message']) ?></td>
                    <td><?= $row['created_at'] ?></td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="alert alert-info">You haven't sent any messages yet.</div>
    <?php endif; ?>
</div>
</body>
</html>
