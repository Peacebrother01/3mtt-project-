<?php
// admin/edit_student.php
session_start();
require_once "../includes/db.php";

// Only admins allowed
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Fetch student details by ID
if (isset($_GET['id'])) {
    $student_id = $_GET['id'];
    
    // Fetch student information
    $student_result = $conn->query("
        SELECT students.*, classes.class_name, GROUP_CONCAT(subjects.name) AS subjects
        FROM students
        LEFT JOIN classes ON students.class_id = classes.id
        LEFT JOIN student_subjects ON students.id = student_subjects.student_id
        LEFT JOIN subjects ON student_subjects.subject_id = subjects.id
        WHERE students.id = $student_id
        GROUP BY students.id
    ");
    
    if ($student_result->num_rows > 0) {
        $student = $student_result->fetch_assoc();
    } else {
        // If student is not found, redirect to manage students page
        header("Location: manage_student.php");
        exit();
    }
}

// Fetch all subjects
$subjects_result = $conn->query("SELECT * FROM subjects ORDER BY name ASC");

// Fetch all classes
$classes_result = $conn->query("SELECT * FROM classes ORDER BY class_name ASC");

// Update student details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $matric_number = $_POST['matric_number'];
    $gender = $_POST['gender'];
    $class_id = $_POST['class_id'];
    $status = $_POST['status'];
    
    // Update student information
    $update_query = "
        UPDATE students 
        SET name = '$name', matric_number = '$matric_number', gender = '$gender', class_id = '$class_id', status = '$status'
        WHERE id = $student_id
    ";
    $conn->query($update_query);
    
    // Update subjects
    $selected_subjects = isset($_POST['subjects']) ? $_POST['subjects'] : [];
    
    // Remove current subjects
    $conn->query("DELETE FROM student_subjects WHERE student_id = $student_id");
    
    // Assign selected subjects to student
    foreach ($selected_subjects as $subject_id) {
        $conn->query("INSERT INTO student_subjects (student_id, subject_id) VALUES ($student_id, $subject_id)");
    }
    
    // Redirect to manage students page
    header("Location: manage_student.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Edit Student</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
</head>
<body>

<?php include 'admin_header_info.php'; ?>

<div class="container-fluid">
  <div class="row">
    <?php include 'admin_sidebar.php'; ?>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Edit Student: <?= htmlspecialchars($student['name']) ?></h1>
      </div>

      <form method="POST">
        <div class="mb-3">
          <label for="name" class="form-label">Name</label>
          <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($student['name']) ?>" required />
        </div>

        <div class="mb-3">
          <label for="matric_number" class="form-label">Matric Number</label>
          <input type="text" class="form-control" id="matric_number" name="matric_number" value="<?= htmlspecialchars($student['matric_number']) ?>" required />
        </div>

        <div class="mb-3">
          <label for="gender" class="form-label">Gender</label>
          <select class="form-select" id="gender" name="gender" required>
            <option value="male" <?= $student['gender'] === 'male' ? 'selected' : '' ?>>Male</option>
            <option value="female" <?= $student['gender'] === 'female' ? 'selected' : '' ?>>Female</option>
          </select>
        </div>

        <div class="mb-3">
          <label for="class_id" class="form-label">Class</label>
          <select class="form-select" id="class_id" name="class_id" required>
            <?php while ($class = $classes_result->fetch_assoc()): ?>
              <option value="<?= $class['id'] ?>" <?= $student['class_id'] == $class['id'] ? 'selected' : '' ?>><?= htmlspecialchars($class['class_name']) ?></option>
            <?php endwhile; ?>
          </select>
        </div>

        <div class="mb-3">
          <label for="status" class="form-label">Status</label>
          <select class="form-select" id="status" name="status" required>
            <option value="active" <?= $student['status'] === 'active' ? 'selected' : '' ?>>Active</option>
            <option value="inactive" <?= $student['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
            <option value="suspended" <?= $student['status'] === 'suspended' ? 'selected' : '' ?>>Suspended</option>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label">Subjects</label><br />
          <?php while ($subject = $subjects_result->fetch_assoc()): ?>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" name="subjects[]" value="<?= $subject['id'] ?>"
                <?= in_array($subject['id'], explode(',', $student['subjects'])) ? 'checked' : '' ?> />
              <label class="form-check-label"><?= htmlspecialchars($subject['name']) ?></label>
            </div>
          <?php endwhile; ?>
        </div>

        <button type="submit" class="btn btn-success">Update Student</button>
      </form>
    </main>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
