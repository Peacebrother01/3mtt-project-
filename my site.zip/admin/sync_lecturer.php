<?php
require_once "../includes/db.php";

// Fetch subjects that have a lecturer assigned
$query = "SELECT id AS subject_id, lecturer_id FROM subjects WHERE lecturer_id IS NOT NULL";
$result = $conn->query($query);

while ($row = $result->fetch_assoc()) {
    $subject_id = $row['subject_id'];
    $lecturer_id = $row['lecturer_id'];

    // Check if this lecturer-subject pair already exists
    $check = $conn->prepare("SELECT id FROM lecturer_subjects WHERE lecturer_id = ? AND subject_id = ?");
    $check->bind_param("ii", $lecturer_id, $subject_id);
    $check->execute();
    $check->store_result();

    if ($check->num_rows == 0) {
        // Insert it
        $insert = $conn->prepare("INSERT INTO lecturer_subjects (lecturer_id, subject_id) VALUES (?, ?)");
        $insert->bind_param("ii", $lecturer_id, $subject_id);
        $insert->execute();
    }

    $check->close();
}

echo "Lecturer-subject assignments synced successfully.";
?>
