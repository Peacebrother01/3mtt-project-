<?php
// delete_lecture.php
session_start();
require_once "../includes/db.php";

// Only admins allowed
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Validate lecture ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: manage_lectures.php");
    exit();
}

$lectureId = (int) $_GET['id'];

// Fetch file info for deletion
$stmt = $conn->prepare("SELECT file_path FROM lectures WHERE id = ?");
$stmt->bind_param("i", $lectureId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $lecture = $result->fetch_assoc();
    $filePath = "../uploads/lectures/" . $lecture['file_path'];

    // Delete lecture record
    $deleteStmt = $conn->prepare("DELETE FROM lectures WHERE id = ?");
    $deleteStmt->bind_param("i", $lectureId);
    if ($deleteStmt->execute()) {
        // Delete file from server
        if (file_exists($filePath)) {
            unlink($filePath);
        }
    }
}

header("Location: manage_lectures.php");
exit();
