<?php
// dashboard/logout.php
session_start();
include '../includes/db.php';

// If you’re tracking user session durations in user_logs, update logout_time
if (!empty($_SESSION['log_id'])) {
    $logId = (int)$_SESSION['log_id'];
    $stmt = $conn->prepare("UPDATE user_logs SET logout_time = NOW() WHERE id = ?");
    $stmt->bind_param("i", $logId);
    $stmt->execute();
    unset($_SESSION['log_id']);
}

// Clear all session data
$_SESSION = [];
session_destroy();

// Redirect to login page
header("Location: login.php");
exit;


