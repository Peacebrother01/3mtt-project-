<?php
session_start();
require_once "../includes/db.php";
if (!isset($_SESSION['user']) || $_SESSION['user']['role']!=='instructor') {
  header("Location: ../login.php"); exit;
}

$lecturer_id = $_SESSION['user']['id'];
if (!isset($_GET['class_id']) || !is_numeric($_GET['class_id'])) {
  header("Location: lecturer_my_classes.php"); exit;
}
$class_id = (int)$_GET['class_id'];

// Verify this lecturer actually teaches a subject in this class
$chk = $conn->query("
  SELECT 1
  FROM subjects s
  JOIN lecturer_subjects ls ON s.id = ls.subject_id
  WHERE s.class_id = $class_id
    AND ls.lecturer_id = $lecturer_id
");
if (!$chk->num_rows) {
  header("Location: lecturer_my_classes.php"); exit;
}

// Fetch class name
$cls = $conn->query("SELECT class_name FROM classes WHERE id = $class_id")->fetch_assoc();

// Fetch students assigned to this class
$students = $conn->query("
  SELECT u.id, u.full_name, u.email
  FROM class_students cs
  JOIN users u ON cs.student_id = u.id
  WHERE cs.class_id = $class_id
  ORDER BY u.full_name
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Students in <?= htmlspecialchars($cls['class_name']) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<?php include 'lecturer_header_info.php'; ?>
<body>
<div class="container mt-5">
  <h2>Students — <?= htmlspecialchars($cls['class_name']) ?></h2>
  <?php if ($students->num_rows): ?>
    <table class="table table-striped">
      <thead>
        <tr><th>#</th><th>Name</th><th>Email</th></tr>
      </thead>
      <tbody>
        <?php $i=1; while ($stu = $students->fetch_assoc()): ?>
          <tr>
            <td><?= $i++ ?></td>
            <td><?= htmlspecialchars($stu['full_name']) ?></td>
            <td><?= htmlspecialchars($stu['email']) ?></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  <?php else: ?>
    <div class="alert alert-warning">No students are currently assigned to this class.</div>
  <?php endif; ?>

  <a href="lecturer_my_classes.php" class="btn btn-secondary">Back to My Classes</a>
</div>
</body>
</html>
