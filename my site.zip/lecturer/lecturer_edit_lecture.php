<?php
session_start();
require_once "../includes/db.php";

// Redirect if not a lecturer
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

$lecturer_id = $_SESSION['user']['id'];

if (!isset($_GET['id'])) {
    header("Location: lecturer_manage_lectures.php");
    exit();
}

$lecture_id = intval($_GET['id']);

// Fetch lecture to be edited
$lectureQuery = $conn->prepare("
    SELECT * FROM lectures 
    WHERE id = ? AND uploaded_by = ?
");
$lectureQuery->bind_param("ii", $lecture_id, $lecturer_id);
$lectureQuery->execute();
$lectureResult = $lectureQuery->get_result();

if ($lectureResult->num_rows === 0) {
    $_SESSION['message'] = "Lecture not found or access denied.";
    header("Location: lecturer_manage_lectures.php");
    exit();
}

$lecture = $lectureResult->fetch_assoc();

// Get lecturer's subjects
$subjectResult = $conn->query("
    SELECT subjects.id, subjects.name 
    FROM subjects 
    JOIN lecturer_subjects ON subjects.id = lecturer_subjects.subject_id 
    WHERE lecturer_subjects.lecturer_id = $lecturer_id
");

$subjects = [];
while ($row = $subjectResult->fetch_assoc()) {
    $subjects[] = $row;
}

// Get all classes
$classResult = $conn->query("SELECT * FROM classes");
$classes = [];
while ($row = $classResult->fetch_assoc()) {
    $classes[] = $row;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $subject_id = $_POST['subject_id'];
    $class_id = $_POST['class_id'];

    // File update (optional)
    if (isset($_FILES['lecture_file']) && $_FILES['lecture_file']['error'] === 0) {
        $file_name = $_FILES['lecture_file']['name'];
        $file_tmp = $_FILES['lecture_file']['tmp_name'];
        $file_type = $_FILES['lecture_file']['type'];
        $destination = "../uploads/" . $file_name;

        if (move_uploaded_file($file_tmp, $destination)) {
            $stmt = $conn->prepare("UPDATE lectures 
                SET title=?, description=?, subject_id=?, class_id=?, file_path=?, file_type=? 
                WHERE id=? AND uploaded_by=?");
            $stmt->bind_param("ssisssii", $title, $description, $subject_id, $class_id, $destination, $file_type, $lecture_id, $lecturer_id);
        }
    } else {
        $stmt = $conn->prepare("UPDATE lectures 
            SET title=?, description=?, subject_id=?, class_id=? 
            WHERE id=? AND uploaded_by=?");
        $stmt->bind_param("ssiiii", $title, $description, $subject_id, $class_id, $lecture_id, $lecturer_id);
    }

    if ($stmt->execute()) {
        $_SESSION['message'] = "Lecture updated successfully.";
        header("Location: lecturer_manage_lectures.php");
        exit();
    } else {
        $error = "Error updating lecture.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Lecture</title>
    

<?php include 'lecturer_header_info.php'; ?>
<?php include 'lecturer_sidebar.php'; ?>

<body class="container mt-5">
    <h2 class="mb-4">Edit Lecture</h2>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label class="form-label">Lecture Title</label>
            <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($lecture['title']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control" rows="4"><?= htmlspecialchars($lecture['description']) ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Subject</label>
            <select name="subject_id" class="form-select" required>
                <option value="">-- Select Subject --</option>
                <?php foreach ($subjects as $subject): ?>
                    <option value="<?= $subject['id'] ?>" <?= ($subject['id'] == $lecture['subject_id']) ? 'selected' : '' ?>>
                        <?= $subject['name'] ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Class</label>
            <select name="class_id" class="form-select" required>
                <option value="">-- Select Class --</option>
                <?php foreach ($classes as $class): ?>
                    <option value="<?= $class['id'] ?>" <?= ($class['id'] == $lecture['class_id']) ? 'selected' : '' ?>>
                        <?= $class['class_name'] ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Upload New File (optional)</label>
            <input type="file" name="lecture_file" class="form-control">
            <small class="form-text text-muted">Current file: <?= basename($lecture['file_path']) ?></small>
        </div>

        <button type="submit" class="btn btn-primary">Update Lecture</button>
        <a href="lecturer_manage_lectures.php" class="btn btn-secondary">Cancel</a>
    </form>
    <br/><br/><br/><br/><br/>
    <?php include "lecturer_footer.php"; ?>
