<?php
// dashboard/admin_dashboard.php
include '../includes/db.php';
session_start();

// Prevent back button after logout
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies

// Check if user is logged in
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}


// Fetch total Admins, Lecturers, Students, and Subjects count
$total_admin_query = "SELECT COUNT(*) AS total_admin FROM users WHERE role = 'admin'";
$total_lecturer_query = "SELECT COUNT(*) AS total_lecturer FROM users WHERE role = 'instructor'";
$total_students_query = "SELECT COUNT(*) AS total_students FROM students";
$total_subjects_query = "SELECT COUNT(*) AS total_subjects FROM subjects";

// Execute queries
$total_admin_result = mysqli_query($conn, $total_admin_query);
$total_lecturer_result = mysqli_query($conn, $total_lecturer_query);
$total_students_result = mysqli_query($conn, $total_students_query);
$total_subjects_result = mysqli_query($conn, $total_subjects_query);

// Fetch results
$total_admin = mysqli_fetch_assoc($total_admin_result)['total_admin'];
$total_lecturer = mysqli_fetch_assoc($total_lecturer_result)['total_lecturer'];
$total_students = mysqli_fetch_assoc($total_students_result)['total_students'];
$total_subjects = mysqli_fetch_assoc($total_subjects_result)['total_subjects'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>

<?php include 'admin_header_info.php'; ?>
<?php include 'admin_sidebar.php'; ?>

<div class="container mt-4">
  <h2 class="mb-4">
    <i class="fas fa-tachometer-alt"></i> Admin Dashboard
  </h2>

  <div class="row">
    <!-- Total Admins Card -->
    <div class="col-md-3 mb-3">
      <div class="card text-white bg-primary">
        <div class="card-body">
          <h5 class="card-title"><i class="fas fa-user-shield"></i> Total Admins</h5>
          <p class="card-text"><?= $total_admin ?></p>
        </div>
      </div>
    </div>

    <!-- Total Lecturers Card -->
    <div class="col-md-3 mb-3">
      <div class="card text-white bg-success">
        <div class="card-body">
          <h5 class="card-title"><i class="fas fa-chalkboard-teacher"></i> Total Lecturers</h5>
          <p class="card-text"><?= $total_lecturer ?></p>
        </div>
      </div>
    </div>

    <!-- Total Students Card -->
    <div class="col-md-3 mb-3">
      <div class="card text-white bg-warning">
        <div class="card-body">
          <h5 class="card-title"><i class="fas fa-graduation-cap"></i> Total Students</h5>
          <p class="card-text"><?= $total_students ?></p>
        </div>
      </div>
    </div>

    <!-- Total Subjects Card -->
    <div class="col-md-3 mb-3">
      <div class="card text-white bg-info">
        <div class="card-body">
          <h5 class="card-title"><i class="fas fa-book"></i> Total Subjects</h5>
          <p class="card-text"><?= $total_subjects ?></p>
        </div>
      </div>
    </div>
  </div>

  <!-- Recent Activities Section -->
  <div class="card">
    <div class="card-header bg-info text-white">
      <h5 class="mb-0"><i class="fas fa-history"></i> Recent Activity</h5>
    </div>
    <div class="card-body">
      <p>Display recent activities here, like user logins, changes made to subjects, etc.</p>
      <a href="manage_user_log.php" class="btn btn-primary">View User Logs</a>
    </div>
  </div>

  <!-- Quick Links Section -->
  <div class="card mt-3">
    <div class="card-header bg-secondary text-white">
      <h5 class="mb-0"><i class="fas fa-link"></i> Quick Links</h5>
    </div>
    <div class="card-body">
      <a href="manage_subject.php" class="btn btn-warning btn-sm">Manage Subjects</a>
      <a href="manage_students.php" class="btn btn-success btn-sm">Manage Students</a>
      <a href="manage_users.php" class="btn btn-primary btn-sm">Manage Users</a>
    </div>
  </div>
</div>

<?php include 'admin_footer.php'; ?>


