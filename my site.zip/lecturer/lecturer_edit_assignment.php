<?php
// lecturer_edit_assignment.php
session_start();
require_once "../includes/db.php";

// Redirect if not a lecturer
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'instructor') {
    header("Location: ../login.php");
    exit();
}

$lecturer_id = $_SESSION['user']['id'];

// Validate assignment ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: lecturer_manage_assignments.php");
    exit();
}
$assignment_id = (int)$_GET['id'];

// Fetch the assignment (ensure it belongs to this lecturer)
$stmt = $conn->prepare("SELECT * FROM assignments WHERE id = ? AND lecturer_id = ?");
$stmt->bind_param("ii", $assignment_id, $lecturer_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    $_SESSION['message'] = "Assignment not found or access denied.";
    header("Location: lecturer_manage_assignments.php");
    exit();
}
$assignment = $result->fetch_assoc();

// Fetch subjects assigned to this lecturer
$subjStmt = $conn->prepare("
    SELECT subjects.id, subjects.name
    FROM lecturer_subjects
    JOIN subjects ON lecturer_subjects.subject_id = subjects.id
    WHERE lecturer_subjects.lecturer_id = ?
");
$subjStmt->bind_param("i", $lecturer_id);
$subjStmt->execute();
$subjectsResult = $subjStmt->get_result();

// Fetch all classes
$classResult = $conn->query("SELECT id, class_name FROM classes");

$error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject_id  = $_POST['subject_id'];
    $class_id    = $_POST['class_id'];
    $title       = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $deadline    = $_POST['deadline'];
    $file_path   = $assignment['file_path'];
    $file_type   = $assignment['file_type'];

    // Handle optional file replacement
    if (!empty($_FILES['assignment_file']['name'])) {
        $upload_dir = "../uploads/assignments/";
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        // remove old file
        if ($file_path && file_exists($file_path)) unlink($file_path);
        // upload new
        $fname     = time() . "_" . basename($_FILES['assignment_file']['name']);
        $dest      = $upload_dir . $fname;
        move_uploaded_file($_FILES['assignment_file']['tmp_name'], $dest);
        $file_path = $dest;
        $file_type = pathinfo($dest, PATHINFO_EXTENSION);
    }

    // Build update query
    $stmt = $conn->prepare("
        UPDATE assignments
        SET title = ?, description = ?, subject_id = ?, class_id = ?, deadline = ?, file_path = ?, file_type = ?
        WHERE id = ? AND lecturer_id = ?
    ");
    $stmt->bind_param(
        "ssiiissii",
        $title, $description, $subject_id, $class_id, $deadline,
        $file_path, $file_type,
        $assignment_id, $lecturer_id
    );

    if ($stmt->execute()) {
        $_SESSION['message'] = "Assignment updated successfully.";
        header("Location: lecturer_manage_assignments.php");
        exit();
    } else {
        $error = "Error updating assignment.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Assignment</title>
  

<?php include 'lecturer_header_info.php'; ?>

<body>
<div class="container-fluid">
  <div class="row">
    <?php include 'lecturer_sidebar.php'; ?>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
      <h2 class="mb-4">Edit Assignment</h2>

      <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
      <?php elseif (isset($_SESSION['message'])): ?>
        <div class="alert alert-success">
          <?= $_SESSION['message']; unset($_SESSION['message']); ?>
        </div>
      <?php endif; ?>

      <form method="post" enctype="multipart/form-data" class="card p-4 shadow-sm">
        <div class="row g-3">
          <div class="col-md-6">
            <label for="subject_id" class="form-label">Subject</label>
            <select id="subject_id" name="subject_id" class="form-select" required>
              <?php while ($sub = $subjectsResult->fetch_assoc()): ?>
                <option value="<?= $sub['id'] ?>"
                  <?= $sub['id']==$assignment['subject_id']?'selected':''?>>
                  <?= htmlspecialchars($sub['name']) ?>
                </option>
              <?php endwhile; ?>
            </select>
          </div>

          <div class="col-md-6">
            <label for="class_id" class="form-label">Class</label>
            <select id="class_id" name="class_id" class="form-select" required>
              <?php while ($cls = $classResult->fetch_assoc()): ?>
                <option value="<?= $cls['id'] ?>"
                  <?= $cls['id']==$assignment['class_id']?'selected':''?>>
                  <?= htmlspecialchars($cls['class_name']) ?>
                </option>
              <?php endwhile; ?>
            </select>
          </div>

          <div class="col-12">
            <label for="title" class="form-label">Title</label>
            <input type="text" id="title" name="title"
                   value="<?= htmlspecialchars($assignment['title']) ?>"
                   class="form-control" required>
          </div>

          <div class="col-12">
            <label for="description" class="form-label">Description</label>
            <textarea id="description" name="description"
                      class="form-control" rows="4"><?= htmlspecialchars($assignment['description']) ?></textarea>
          </div>

          <div class="col-md-6">
            <label for="deadline" class="form-label">Deadline</label>
            <input type="date" id="deadline" name="deadline"
                   value="<?= htmlspecialchars($assignment['deadline']) ?>"
                   class="form-control" required>
          </div>

          <div class="col-md-6">
            <label class="form-label">Replace File (optional)</label>
            <input type="file" name="assignment_file" class="form-control">
            <?php if ($assignment['file_path']): ?>
              <small class="text-muted">Current: <?= basename($assignment['file_path']) ?></small>
            <?php endif; ?>
          </div>

          <div class="col-12 text-end">
            <button type="submit" class="btn btn-primary">Update Assignment</button>
            <a href="lecturer_manage_assignment.php" class="btn btn-secondary ms-2">Cancel</a>
          </div>
        </div>
      </form>
    </main>
  </div>
</div>
</body>
</html>
